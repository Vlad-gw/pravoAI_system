#!/bin/bash
set -e
python3 - <<'PY'
import secrets
for name in ['POSTGRES_PASSWORD','REDIS_PASSWORD','JWT_SECRET','DEV_ADMIN_TOKEN']:
    print(f'{name}={secrets.token_urlsafe(48)}')
PY
read -r -p "Нажмите Enter для выхода..."
