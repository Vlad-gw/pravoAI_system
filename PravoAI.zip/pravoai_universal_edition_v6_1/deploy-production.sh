#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
if [ ! -f .env.production ]; then
  echo "❌ Нет .env.production. Скопируйте .env.production.example и заполните CHANGE_ME значения."
  exit 1
fi
./preflight-production.command
if ! command -v docker >/dev/null || ! docker info >/dev/null 2>&1; then
  echo "❌ Docker недоступен"
  exit 1
fi
echo "▶ Сборка production стека"
docker compose --env-file .env.production -f docker-compose.production.yml up --build -d
echo "⏳ Проверяю контейнеры..."
sleep 8
docker compose --env-file .env.production -f docker-compose.production.yml ps
echo ""
echo "✅ Стек запущен. После первого запуска создайте администратора:"
echo "   export PRAVOAI_ADMIN_PASSWORD='СИЛЬНЫЙ_ПАРОЛЬ'"
echo "   docker compose --env-file .env.production -f docker-compose.production.yml exec -e PRAVOAI_ADMIN_PASSWORD api python -m app.cli.create_admin --email admin@your-domain.ru"
