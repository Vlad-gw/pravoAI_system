#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"

if ! docker info >/dev/null 2>&1; then echo "Docker Desktop не запущен"; exit 1; fi

echo "1/8 Health + readiness"
curl -fsS http://localhost:8000/api/v1/health >/dev/null
curl -fsS http://localhost:8000/api/v1/ready >/dev/null
echo "✅ API готов"

echo "2/8 Backend tests"
docker compose exec -T api pytest -q

echo "3/8 Alembic"
docker compose exec -T api alembic current

echo "4/8 Frontend"
curl -fsSI http://localhost:3000 | head -n 1

echo "5/8 Admin login"
LOGIN=$(curl -fsS -H "Content-Type: application/json" -d '{"email":"admin@pravoai.local","password":"PravoAI-Admin-2026!"}' http://localhost:8000/api/v1/auth/login)
TOKEN=$(python3 - <<'PY' "$LOGIN"
import json,sys
print(json.loads(sys.argv[1])['access_token'])
PY
)

echo "6/8 Универсальный ИИ: неюридический вопрос"
GENERAL=$(curl -fsS -H "Content-Type: application/json" -H "Authorization: Bearer $TOKEN" \
  -d '{"message":"Сколько будет 17 умножить на 23? Ответь кратко и объясни вычисление."}' \
  http://localhost:8000/api/v1/chat/messages)
python3 - <<'PY' "$GENERAL"
import json,sys
x=json.loads(sys.argv[1])
assert x.get('mode')=='general', x
assert '391' in x.get('short_answer',''), x.get('short_answer')
assert x.get('sources')==[], x.get('sources')
assert 'ollama:' in x.get('provider','') or x.get('provider'), x
print('✅ Общий вопрос обслужен реальной ИИ-моделью:', x.get('provider'))
PY

echo "7/8 Юридический режим + контекст"
LEGAL=$(curl -fsS -H "Content-Type: application/json" -H "Authorization: Bearer $TOKEN" \
  -d '{"message":"При увольнении в связи с выходом на пенсию мне не выплатили обещанное выходное пособие. Что делать?"}' \
  http://localhost:8000/api/v1/chat/messages)
python3 - <<'PY' "$LEGAL"
import json,sys
x=json.loads(sys.argv[1])
assert x.get('mode')=='legal', x
arts={str(s.get('article')) for s in x.get('sources',[])}
assert '178' in arts or '140' in arts, (arts,x.get('short_answer'))
assert '80' not in arts or '178' in arts, arts
print('✅ Юридический режим:', x.get('provider'), 'статьи', sorted(arts))
PY

echo "8/8 Правовая база"
DOCS=$(curl -fsS http://localhost:8000/api/v1/legal/documents)
python3 - <<'PY' "$DOCS"
import json,sys
items=json.loads(sys.argv[1]); assert len(items)>=3
print(f'✅ Правовая база: {len(items)} документов')
PY

echo "✅ Проверка ПравоAI Universal Edition 6.0 завершена"
