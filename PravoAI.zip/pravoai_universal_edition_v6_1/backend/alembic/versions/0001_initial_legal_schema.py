"""Initial legal document schema with temporal versions and pgvector.

Revision ID: 0001
Revises:
Create Date: 2026-09-11
"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from pgvector.sqlalchemy import VECTOR
from sqlalchemy.dialects import postgresql

revision: str = "0001"
down_revision: Union[str, Sequence[str], None] = None
branch_labels = None
depends_on = None

EMBEDDING_DIM = 1024


def upgrade() -> None:
    op.execute("CREATE EXTENSION IF NOT EXISTS vector")

    op.create_table(
        "legal_documents",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True, nullable=False),
        sa.Column("document_type", sa.String(length=100), nullable=False),
        sa.Column("title", sa.Text(), nullable=False),
        sa.Column("short_title", sa.String(length=255), nullable=True),
        sa.Column("number", sa.String(length=100), nullable=True),
        sa.Column("adoption_date", sa.Date(), nullable=True),
        sa.Column("source_name", sa.String(length=255), nullable=False),
        sa.Column("source_url", sa.Text(), nullable=False),
        sa.Column("external_id", sa.String(length=255), nullable=True),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.func.now(),
            nullable=False,
        ),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            server_default=sa.func.now(),
            nullable=False,
        ),
        sa.UniqueConstraint("external_id", name="uq_legal_documents_external_id"),
    )
    op.create_index(
        "ix_legal_documents_document_type",
        "legal_documents",
        ["document_type"],
    )
    op.create_index("ix_legal_documents_number", "legal_documents", ["number"])

    op.create_table(
        "legal_document_versions",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True, nullable=False),
        sa.Column(
            "legal_document_id",
            postgresql.UUID(as_uuid=True),
            sa.ForeignKey("legal_documents.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column("revision_date", sa.Date(), nullable=True),
        sa.Column("publication_date", sa.Date(), nullable=True),
        sa.Column("effective_from", sa.Date(), nullable=False),
        sa.Column("effective_to", sa.Date(), nullable=True),
        sa.Column("raw_text", sa.Text(), nullable=False),
        sa.Column("content_hash", sa.String(length=64), nullable=False),
        sa.Column(
            "metadata_json",
            postgresql.JSONB(astext_type=sa.Text()),
            server_default=sa.text("'{}'::jsonb"),
            nullable=False,
        ),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.func.now(),
            nullable=False,
        ),
        sa.UniqueConstraint(
            "legal_document_id",
            "content_hash",
            name="uq_legal_document_version_content_hash",
        ),
    )
    op.create_index(
        "ix_legal_document_versions_legal_document_id",
        "legal_document_versions",
        ["legal_document_id"],
    )
    op.create_index(
        "ix_legal_document_versions_effective_from",
        "legal_document_versions",
        ["effective_from"],
    )
    op.create_index(
        "ix_legal_document_versions_effective_to",
        "legal_document_versions",
        ["effective_to"],
    )
    op.create_index(
        "ix_legal_document_versions_effective_range",
        "legal_document_versions",
        ["legal_document_id", "effective_from", "effective_to"],
    )

    op.create_table(
        "legal_chunks",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True, nullable=False),
        sa.Column(
            "version_id",
            postgresql.UUID(as_uuid=True),
            sa.ForeignKey("legal_document_versions.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column("chapter", sa.String(length=255), nullable=True),
        sa.Column("article", sa.String(length=100), nullable=True),
        sa.Column("part", sa.String(length=100), nullable=True),
        sa.Column("paragraph", sa.String(length=100), nullable=True),
        sa.Column("text", sa.Text(), nullable=False),
        sa.Column("parent_text", sa.Text(), nullable=True),
        sa.Column(
            "metadata_json",
            postgresql.JSONB(astext_type=sa.Text()),
            server_default=sa.text("'{}'::jsonb"),
            nullable=False,
        ),
        sa.Column("embedding", VECTOR(EMBEDDING_DIM), nullable=True),
        sa.Column(
            "search_tsv",
            postgresql.TSVECTOR(),
            sa.Computed(
                "to_tsvector('russian', coalesce(text, ''))",
                persisted=True,
            ),
            nullable=False,
        ),
    )
    op.create_index("ix_legal_chunks_version_id", "legal_chunks", ["version_id"])
    op.create_index("ix_legal_chunks_article", "legal_chunks", ["article"])
    op.create_index(
        "ix_legal_chunks_version_article",
        "legal_chunks",
        ["version_id", "article"],
    )
    op.create_index(
        "ix_legal_chunks_search_tsv_gin",
        "legal_chunks",
        ["search_tsv"],
        postgresql_using="gin",
    )
    op.create_index(
        "ix_legal_chunks_embedding_hnsw",
        "legal_chunks",
        ["embedding"],
        postgresql_using="hnsw",
        postgresql_with={"m": 16, "ef_construction": 64},
        postgresql_ops={"embedding": "vector_cosine_ops"},
    )


def downgrade() -> None:
    op.drop_table("legal_chunks")
    op.drop_table("legal_document_versions")
    op.drop_table("legal_documents")
    # Keep extension installed: other schemas may depend on it.
