"""Attach uploaded documents to conversations.

Revision ID: 0004
Revises: 0003
"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

revision = "0004"
down_revision = "0003"
branch_labels = None
depends_on = None


def upgrade():
    op.add_column("uploaded_documents", sa.Column("conversation_id", postgresql.UUID(as_uuid=True), nullable=True))
    op.create_index("ix_uploaded_documents_conversation_id", "uploaded_documents", ["conversation_id"], unique=False)
    op.create_foreign_key("fk_uploaded_documents_conversation", "uploaded_documents", "conversations", ["conversation_id"], ["id"], ondelete="SET NULL")


def downgrade():
    op.drop_constraint("fk_uploaded_documents_conversation", "uploaded_documents", type_="foreignkey")
    op.drop_index("ix_uploaded_documents_conversation_id", table_name="uploaded_documents")
    op.drop_column("uploaded_documents", "conversation_id")
