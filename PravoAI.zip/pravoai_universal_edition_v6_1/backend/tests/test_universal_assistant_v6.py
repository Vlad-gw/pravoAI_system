from datetime import date
from uuid import uuid4

from app.services.assistant import detect_mode
from app.services.chat import _retirement_severance_answer
from app.services.hybrid_search import SearchHit


def hit(article: str, text: str = "норма") -> SearchHit:
    return SearchHit(
        chunk_id=uuid4(), document_id=uuid4(),
        document_title="Трудовой кодекс Российской Федерации", document_number="197-ФЗ",
        article=article, part=None, text=text, effective_from=date(2026, 1, 1), effective_to=None,
        source_url="https://pravo.gov.ru/", source_name="Официальный интернет-портал правовой информации",
        score=1.0, is_snapshot=True, verified_as_of="2026-09-11",
    )


def test_general_questions_are_not_forced_into_legal_rag():
    assert detect_mode("Напиши функцию на Python для проверки палиндрома") == "general"
    assert detect_mode("Объясни простыми словами, что такое нейронная сеть") == "general"
    assert detect_mode("Привет, как дела?") == "general"


def test_legal_questions_are_routed_automatically():
    assert detect_mode("Работодатель не выплатил зарплату") == "legal"
    assert detect_mode("Не возвращают деньги за товар") == "legal"
    assert detect_mode("При увольнении не выплатили пособие при выходе на пенсию") == "legal"


def test_short_followup_keeps_legal_context():
    assert detect_mode("уже оформлено", prior_area="трудовое право") == "legal"
    assert detect_mode("я ответил", prior_area="трудовое право") == "legal"
    # A genuinely new topic immediately leaves legal mode, even if it is short.
    assert detect_mode("Напиши код на Python", prior_area="трудовое право") == "general"
    assert detect_mode("Какая погода завтра?", prior_area="трудовое право") == "general"
    assert detect_mode("Посоветуй фильм", prior_area="трудовое право") == "general"


def test_retirement_severance_answer_distinguishes_statutory_and_contractual_payment():
    hits = [hit(x) for x in ["127", "140", "178", "236", "392"]]
    data = _retirement_severance_answer(
        "при увольнении в связи с выходом на пенсию не выплатили выходное пособие", hits
    )
    assert data is not None
    assert "общего обязательного" in data["short_answer"]
    arts = {x["article"] for x in data["legal_basis"]}
    assert "178" in arts and "140" in arts
    assert any("коллектив" in x.lower() or "трудов" in x.lower() for x in data["evidence"])
