from datetime import date

from app.domain.temporal import revision_is_active


def test_active_open_ended_revision() -> None:
    assert revision_is_active(
        effective_from=date(2025, 1, 1),
        effective_to=None,
        target_date=date(2026, 9, 11),
    )


def test_revision_is_not_active_before_start() -> None:
    assert not revision_is_active(
        effective_from=date(2025, 1, 1),
        effective_to=None,
        target_date=date(2024, 12, 31),
    )


def test_effective_to_is_exclusive() -> None:
    assert revision_is_active(
        effective_from=date(2024, 1, 1),
        effective_to=date(2025, 1, 1),
        target_date=date(2024, 12, 31),
    )

    assert not revision_is_active(
        effective_from=date(2024, 1, 1),
        effective_to=date(2025, 1, 1),
        target_date=date(2025, 1, 1),
    )
