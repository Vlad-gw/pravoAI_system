from datetime import date
from uuid import uuid4

from app.services.chat import (
    _extractive_answer,
    _filter_hits_to_citations,
    _insufficient_input_answer,
    _is_low_information,
    _prepare_question,
    classify_area,
)
from app.services.hybrid_search import SearchHit


def hit(article: str, text: str, title: str = "Трудовой кодекс Российской Федерации") -> SearchHit:
    return SearchHit(
        chunk_id=uuid4(), document_id=uuid4(), document_title=title,
        document_number="197-ФЗ", article=article, part=None, text=text,
        effective_from=date(2026, 9, 11), effective_to=None,
        source_url="https://pravo.gov.ru/", source_name="Официальный источник",
        score=1.0, is_snapshot=False, verified_as_of=None,
    )


def test_noise_does_not_look_like_legal_question():
    assert _is_low_information("ооол") is True
    assert _insufficient_input_answer()["legal_basis"] == []


def test_short_factual_followup_uses_previous_user_context():
    prepared, used = _prepare_question("два месяца", ["Работодатель не платит зарплату. Что делать?"])
    assert used is True
    assert "зарплату" in prepared
    assert "два месяца" in prepared


def test_salary_answer_is_direct_and_only_uses_salary_sources():
    hits = [
        hit("136", "Статья 136. Зарплата выплачивается не реже чем каждые полмесяца."),
        hit("142", "Статья 142. При задержке более 15 дней возможна приостановка после уведомления."),
        hit("236", "Статья 236. Работодатель выплачивает денежную компенсацию за задержку."),
        hit("356", "Статья 356. Инспекция труда рассматривает обращения работников."),
        hit("392", "Статья 392. По невыплате зарплаты срок обращения в суд один год."),
        hit("80", "Статья 80. Увольнение по собственному желанию."),
        hit("25", "Статья 25. Обмен товара надлежащего качества.", "Закон Российской Федерации «О защите прав потребителей»"),
    ]
    answer = _extractive_answer("Два месяца работодатель не выплачивал зарплату, что делать?", "трудовое право", date(2026, 9, 11), hits)
    assert answer["short_answer"].startswith("Если зарплату не выплачивают")
    cited_articles = {x["article"] for x in answer["legal_basis"]}
    assert "136" in cited_articles and "236" in cited_articles
    assert "80" not in cited_articles
    assert "25" not in cited_articles
    visible = _filter_hits_to_citations(answer, hits)
    assert {x.article for x in visible} == cited_articles


def test_area_classifier_salary_is_labour():
    assert classify_area("Работодатель задерживает заработную плату") == "трудовое право"


def test_simple_resignation_question_is_labour_and_direct():
    assert classify_area("Хочу уволиться") == "трудовое право"
    hits = [hit("80", "Статья 80. Работник имеет право расторгнуть трудовой договор, предупредив работодателя письменно не позднее чем за две недели.")]
    answer = _extractive_answer("Хочу уволиться. Что делать?", "трудовое право", date(2026, 9, 11), hits)
    assert "две недели" in answer["short_answer"]
    assert answer["need_clarification"] is False
    assert {x["article"] for x in answer["legal_basis"]} == {"80"}
