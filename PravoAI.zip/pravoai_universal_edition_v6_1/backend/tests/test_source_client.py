import pytest

from app.services.ingestion.source_client import LegalSourceError, validate_official_url


def test_allows_official_pravo_hosts():
    validate_official_url("https://ips.pravo.gov.ru/api/ips/legislation/document?hash=abc")
    validate_official_url("https://publication.pravo.gov.ru/document/0001202504070015")


def test_rejects_untrusted_host():
    with pytest.raises(LegalSourceError):
        validate_official_url("https://example.com/law")


def test_rejects_http():
    with pytest.raises(LegalSourceError):
        validate_official_url("http://pravo.gov.ru/")
