from app.services.chat import _prepare_question, classify_area
from app.services.legal_document_reader import detect_full_document_request, detect_named_document


def test_full_consumer_law_detected():
    spec = detect_full_document_request("напиши закон о защите прав потребителей полностью")
    assert spec is not None
    assert spec.number == "2300-1"


def test_named_document_breaks_old_labour_context():
    q, used = _prepare_question(
        "напиши закон о защите прав потребителей полностью",
        ["Работодатель уволил меня по сокращению", "Какие доказательства нужны?"],
    )
    assert used is False
    assert q == "напиши закон о защите прав потребителей полностью"
    assert classify_area(q) == "защита прав потребителей"


def test_short_real_followup_still_keeps_context():
    q, used = _prepare_question("уже оформлено", ["Работодатель хочет меня уволить"])
    assert used is True
    assert "Предыдущая ситуация" in q


def test_detect_named_tk():
    spec = detect_named_document("покажи ТК РФ полностью")
    assert spec is not None and spec.number == "197-ФЗ"
