import uuid

from app.domain.citations import validate_citation_source_ids


def test_rejects_citation_not_present_in_retrieval_context() -> None:
    retrieved = {uuid.uuid4(), uuid.uuid4()}
    fake = uuid.uuid4()

    result = validate_citation_source_ids(
        cited_source_ids=[next(iter(retrieved)), fake],
        retrieved_source_ids=retrieved,
    )

    assert result.valid is False
    assert result.invalid_source_ids == (fake,)


def test_accepts_only_retrieved_sources() -> None:
    source = uuid.uuid4()

    result = validate_citation_source_ids(
        cited_source_ids=[source],
        retrieved_source_ids={source},
    )

    assert result.valid is True
    assert result.invalid_source_ids == ()
