import pytest

from app.services.files import safe_filename, validate_upload
from app.services.privacy import mask_pii


def test_masks_common_identifiers():
    text = "Пишите test@example.ru или +7 (999) 123-45-67, СНИЛС 123-456-789 00"
    masked = mask_pii(text)
    assert "test@example.ru" not in masked
    assert "999" not in masked
    assert "123-456-789 00" not in masked
    assert "[EMAIL]" in masked and "[PHONE]" in masked and "[SNILS]" in masked


def test_rejects_fake_pdf_and_binary_txt():
    with pytest.raises(ValueError):
        validate_upload("contract.pdf", b"not a pdf")
    with pytest.raises(ValueError):
        validate_upload("notes.txt", b"hello\x00world")


def test_safe_filename_strips_path_and_unsafe_chars():
    assert safe_filename("../../secret<script>.txt") == "secret_script_.txt"
