from app.services.ingestion.parser import parse_articles, parse_to_chunks


SAMPLE = """
ГЛАВА I. ОБЩИЕ ПОЛОЖЕНИЯ

Статья 1. Предмет регулирования

1. Настоящий закон регулирует тестовые отношения.
2. Второе положение.

Статья 2. Основные понятия

Для целей настоящего закона используются понятия.

Глава II. ОСОБЕННАЯ ЧАСТЬ

Статья 3. Тестовая статья

1. Первый пункт.
"""


def test_parse_articles_preserves_structure():
    articles = parse_articles(SAMPLE)
    assert [item.article for item in articles] == ["1", "2", "3"]
    assert articles[0].chapter == "Глава I. ОБЩИЕ ПОЛОЖЕНИЯ"
    assert articles[2].chapter == "Глава II. ОСОБЕННАЯ ЧАСТЬ"
    assert "Предмет регулирования" in articles[0].text


def test_parse_to_chunks_creates_article_chunks():
    chunks = parse_to_chunks(SAMPLE)
    assert len(chunks) == 3
    assert chunks[1].article == "2"
    assert chunks[1].text.startswith("Статья 2")
