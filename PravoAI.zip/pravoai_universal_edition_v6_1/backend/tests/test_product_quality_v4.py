from datetime import date
from uuid import uuid4

from app.services.chat import _prepare_question, classify_area, _grounded_scenario_answer
from app.services.hybrid_search import SearchHit


def hit(article, doc):
    return SearchHit(
        chunk_id=uuid4(), document_id=uuid4(), document_title=doc, document_number="x",
        article=article, part=None, text=f"Статья {article}. test", effective_from=date(2026, 9, 11),
        effective_to=None, source_url="https://pravo.gov.ru/", source_name="official", score=1.0,
        is_snapshot=True, verified_as_of="2026-09-11",
    )


def consumer_hits():
    z = "Закон Российской Федерации «О защите прав потребителей»"
    g = "Гражданский кодекс Российской Федерации (часть вторая)"
    return [hit("4",z), hit("18",z), hit("21",z), hit("22",z), hit("26.1",z), hit("467",g), hit("468",g), hit("469",g)]


def test_wrong_tile_is_consumer_and_cites_assortment():
    q = "заказали серую плитку в интернет-магазине, а привезли бежевую, что делать?"
    assert classify_area(q) == "защита прав потребителей"
    ans = _grounded_scenario_answer(q, "защита прав потребителей", date(2026,9,11), consumer_hits())
    assert ans
    arts = {x["article"] for x in ans["legal_basis"]}
    assert "468" in arts
    assert "671" not in arts and "687" not in arts
    assert "претенз" in " ".join(ans["recommended_actions"]).lower()


def test_followup_keeps_previous_consumer_context():
    combined, used = _prepare_question("плитка серая, договор был подписан", ["заказали плитку в Лемана Про, привезли не ту, что делать?"])
    assert used
    assert "Лемана" in combined
    assert classify_area(combined) == "защита прав потребителей"


def test_signed_contract_does_not_turn_tile_dispute_into_housing():
    combined, used = _prepare_question("цвет серый, договор подписан", ["заказали плитку, привезли другой цвет"])
    assert used
    assert classify_area(combined) == "защита прав потребителей"


def test_specific_rights_not_generic_fallback():
    q = "заказали плитку, привезли не ту модель"
    ans = _grounded_scenario_answer(q, "защита прав потребителей", date(2026,9,11), consumer_hits())
    assert ans
    text = (ans["short_answer"] + " " + " ".join(ans["recommended_actions"])).lower()
    assert "замен" in text and "возврат" in text


def test_named_colors_and_signed_contract_produce_strong_answer():
    q = "заказали серую плитку, а привезли бежевую; в подписанном договоре указан серый цвет"
    ans = _grounded_scenario_answer(q, "защита прав потребителей", date(2026,9,11), consumer_hits())
    assert ans
    arts = {x["article"] for x in ans["legal_basis"]}
    assert {"467", "468"}.issubset(arts)
    assert "позиция юридически обоснована" in ans["short_answer"].lower()
    assert "подписанный договор" in ans["application_to_case"].lower()
    assert not ans["need_clarification"]


def test_business_purchase_does_not_promise_consumer_law_unconditionally():
    q = "ООО заказало серую плитку для бизнеса, а привезли бежевую"
    ans = _grounded_scenario_answer(q, "защита прав потребителей", date(2026,9,11), consumer_hits())
    assert ans
    arts = {x["article"] for x in ans["legal_basis"]}
    assert "468" in arts
    assert "4" not in arts and "18" not in arts
    assert any("ип/ооо" in w.lower() or "предприниматель" in w.lower() for w in ans["warnings"])
