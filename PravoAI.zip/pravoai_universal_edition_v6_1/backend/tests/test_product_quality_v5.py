from datetime import date
from uuid import uuid4

from app.data.legal_links import reference_url
from app.services.chat import (
    _consumer_refund_pending_answer,
    _grounded_scenario_answer,
    _prepare_question,
    classify_area,
)
from app.services.hybrid_search import SearchHit, _scenario_article_hints


def hit(article: str, doc: str, number: str = "197-ФЗ") -> SearchHit:
    return SearchHit(
        chunk_id=uuid4(), document_id=uuid4(), document_title=doc, document_number=number,
        article=article, part=None, text=f"Статья {article}. Проверенный текст нормы.",
        effective_from=date(2026, 9, 11), effective_to=None,
        source_url="https://pravo.gov.ru/", source_name="official", score=1.0,
        is_snapshot=True, verified_as_of="2026-09-11",
    )


def labour_redundancy_hits():
    d = "Трудовой кодекс Российской Федерации"
    return [hit(a, d) for a in ["62","81","178","179","180","261","392","393","394"]]


def consumer_hits():
    z = "Закон Российской Федерации «О защите прав потребителей»"
    return [
        hit("13", z, "2300-1"), hit("17", z, "2300-1"), hit("18", z, "2300-1"),
        hit("22", z, "2300-1"), hit("23", z, "2300-1"), hit("25", z, "2300-1"),
        hit("26.1", z, "2300-1"),
    ]


def test_redundancy_fake_rehire_gets_correct_law_and_evidence():
    q = "Работника уволили по сокращению штата, но через месяц приняли нового сотрудника на почти такую же должность. Можно оспорить?"
    assert classify_area(q) == "трудовое право"
    ans = _grounded_scenario_answer(q, "трудовое право", date(2026, 9, 11), labour_redundancy_hits())
    assert ans
    arts = {x["article"] for x in ans["legal_basis"]}
    assert {"81", "180", "392"}.issubset(arts)
    assert "80" not in arts
    assert any("штат" in x.lower() for x in ans["evidence"])
    assert any("месяц" in x.lower() for x in ans["deadlines"])
    assert "оспар" in ans["short_answer"].lower()


def test_redundancy_followup_does_not_turn_into_voluntary_resignation():
    prior = ["Работника уволили по сокращению штата, но через месяц взяли нового сотрудника на почти такую же должность. Можно ли оспорить?"]
    prepared, used = _prepare_question("уже оформлено", prior)
    assert used
    ans = _grounded_scenario_answer(prepared, "трудовое право", date(2026, 9, 11), labour_redundancy_hits())
    assert ans
    arts = {x["article"] for x in ans["legal_basis"]}
    assert "81" in arts and "80" not in arts


def test_ambiguous_refund_explains_three_legal_routes_instead_of_random_articles():
    q = "Не возвращают деньги за товар"
    ans = _consumer_refund_pending_answer(q, consumer_hits())
    assert ans
    arts = {x["article"] for x in ans["legal_basis"]}
    assert {"18", "25", "26.1"}.issubset(arts)
    assert ans["need_clarification"] is True
    assert len(ans["clarifying_questions"]) == 2
    assert "труд" not in " ".join(x["document"] for x in ans["legal_basis"]).lower()


def test_retrieval_pins_redundancy_articles():
    hints = _scenario_article_hints("уволили по сокращению штата и взяли нового сотрудника", "трудовое право")
    assert {"81", "178", "179", "180", "392", "394"}.issubset(hints)


def test_article_links_are_exact_and_working_shape():
    assert reference_url("197-ФЗ", "81").startswith("https://www.consultant.ru/document/")
    assert reference_url("197-ФЗ", "392").startswith("https://www.consultant.ru/document/")
    assert reference_url("2300-1", "18").startswith("https://www.consultant.ru/document/")
    assert reference_url("14-ФЗ", "468").startswith("https://www.consultant.ru/document/")
