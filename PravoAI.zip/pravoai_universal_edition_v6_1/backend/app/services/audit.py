from __future__ import annotations

import hashlib
from fastapi import Request
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.app import AuditLog, User


def ip_hash(request: Request) -> str | None:
    ip = request.client.host if request.client else None
    return hashlib.sha256(ip.encode()).hexdigest() if ip else None


async def audit(
    db: AsyncSession,
    request: Request,
    action: str,
    *,
    user: User | None = None,
    target_type: str | None = None,
    target_id: str | None = None,
    metadata: dict | None = None,
) -> None:
    db.add(
        AuditLog(
            actor_user_id=user.id if user else None,
            action=action,
            target_type=target_type,
            target_id=target_id,
            request_id=getattr(request.state, "request_id", None),
            ip_hash=ip_hash(request),
            metadata_json=metadata or {},
        )
    )
