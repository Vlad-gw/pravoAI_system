from __future__ import annotations

import re

# Conservative masking before optional external LLM calls. This does not replace
# a formal data-classification/DLP solution, but prevents the most common direct identifiers
# from being sent in plaintext when MASK_PII_BEFORE_EXTERNAL_LLM=true.
PATTERNS = [
    (re.compile(r"\b[\w.+-]+@[\w.-]+\.[A-Za-zА-Яа-я]{2,}\b"), "[EMAIL]"),
    (re.compile(r"(?<!\d)(?:\+7|8)[\s\-()]*\d{3}[\s\-()]*\d{3}[\s\-]*\d{2}[\s\-]*\d{2}(?!\d)"), "[PHONE]"),
    (re.compile(r"\b\d{3}-\d{3}-\d{3}\s\d{2}\b"), "[SNILS]"),
    (re.compile(r"\b\d{4}\s?\d{6}\b"), "[PASSPORT]"),
    (re.compile(r"\b\d{10}|\d{12}\b"), "[INN_OR_ID]"),
]


def mask_pii(text: str) -> str:
    result = text
    for pattern, replacement in PATTERNS:
        result = pattern.sub(replacement, result)
    return result
