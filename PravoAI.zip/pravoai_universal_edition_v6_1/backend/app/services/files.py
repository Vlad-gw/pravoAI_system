from __future__ import annotations

import io
import re
import zipfile
from pathlib import Path

from docx import Document as DocxDocument
from pypdf import PdfReader

ALLOWED_EXTENSIONS = {".pdf", ".docx", ".txt", ".png", ".jpg", ".jpeg", ".webp"}
MAX_PDF_PAGES = 400
MAX_OCR_PAGES = 60
MAX_DOCX_UNCOMPRESSED = 80 * 1024 * 1024


def safe_filename(name: str) -> str:
    base = Path(name).name
    return re.sub(r"[^A-Za-zА-Яа-яЁё0-9._ -]+", "_", base)[:180]


def validate_upload(filename: str, data: bytes) -> str:
    ext = Path(filename).suffix.lower()
    if ext not in ALLOWED_EXTENSIONS:
        raise ValueError("Поддерживаются PDF, DOCX, TXT, PNG, JPG/JPEG и WEBP")
    if not data:
        raise ValueError("Файл пуст")
    if ext == ".pdf":
        if not data.startswith(b"%PDF-"):
            raise ValueError("Содержимое файла не соответствует формату PDF")
    elif ext == ".docx":
        if not data.startswith(b"PK"):
            raise ValueError("Содержимое файла не соответствует формату DOCX")
        try:
            with zipfile.ZipFile(io.BytesIO(data)) as zf:
                names = set(zf.namelist())
                if "[Content_Types].xml" not in names or "word/document.xml" not in names:
                    raise ValueError("Некорректный DOCX")
                total = sum(x.file_size for x in zf.infolist())
                if total > MAX_DOCX_UNCOMPRESSED:
                    raise ValueError("DOCX слишком большой после распаковки")
                # Protect against pathological compression ratios in individual members.
                for item in zf.infolist():
                    compressed = max(item.compress_size, 1)
                    if item.file_size > 20 * 1024 * 1024 and item.file_size / compressed > 150:
                        raise ValueError("DOCX имеет подозрительную степень сжатия")
        except zipfile.BadZipFile as exc:
            raise ValueError("Поврежденный DOCX") from exc
    elif ext == ".txt":
        if b"\x00" in data[:8192]:
            raise ValueError("TXT содержит бинарные данные")
    elif ext == ".png":
        if not data.startswith(b"\x89PNG\r\n\x1a\n"):
            raise ValueError("Содержимое файла не соответствует формату PNG")
    elif ext in {".jpg", ".jpeg"}:
        if not data.startswith(b"\xff\xd8\xff"):
            raise ValueError("Содержимое файла не соответствует формату JPEG")
    elif ext == ".webp":
        if len(data) < 12 or not (data.startswith(b"RIFF") and data[8:12] == b"WEBP"):
            raise ValueError("Содержимое файла не соответствует формату WEBP")
    return ext


def _ocr_image_bytes(data: bytes) -> str:
    try:
        from PIL import Image
        import pytesseract
    except ImportError as exc:  # pragma: no cover - production image includes deps
        raise ValueError("OCR-модуль не установлен на сервере") from exc
    try:
        with Image.open(io.BytesIO(data)) as image:
            image.verify()
        with Image.open(io.BytesIO(data)) as image:
            # Prevent decompression-bomb style images from exhausting RAM.
            if image.width * image.height > 60_000_000:
                raise ValueError("Изображение имеет слишком большое разрешение")
            return pytesseract.image_to_string(image, lang="rus+eng").strip()
    except ValueError:
        raise
    except Exception as exc:
        raise ValueError("Не удалось распознать изображение") from exc


def _ocr_pdf(data: bytes, page_count: int) -> str:
    if page_count > MAX_OCR_PAGES:
        raise ValueError(
            f"Сканированный PDF содержит {page_count} страниц; OCR ограничен {MAX_OCR_PAGES} страницами за один файл"
        )
    try:
        from pdf2image import convert_from_bytes
        import pytesseract
    except ImportError as exc:  # pragma: no cover - production image includes deps
        raise ValueError("OCR-модуль не установлен на сервере") from exc
    try:
        images = convert_from_bytes(data, dpi=180, fmt="jpeg", thread_count=1)
        chunks = [pytesseract.image_to_string(img, lang="rus+eng").strip() for img in images]
        return "\n\n".join(x for x in chunks if x).strip()
    except Exception as exc:
        raise ValueError("Не удалось выполнить OCR для PDF") from exc


def extract_text(filename: str, data: bytes) -> str:
    ext = validate_upload(filename, data)
    if ext == ".txt":
        # UTF-8 is preferred; replacement keeps a malformed byte from crashing ingestion.
        return data.decode("utf-8", errors="replace")
    if ext == ".docx":
        doc = DocxDocument(io.BytesIO(data))
        paragraphs = [p.text for p in doc.paragraphs if p.text.strip()]
        # Include table content; contracts frequently keep key conditions in tables.
        for table in doc.tables:
            for row in table.rows:
                cells = [cell.text.strip() for cell in row.cells if cell.text.strip()]
                if cells:
                    paragraphs.append(" | ".join(cells))
        return "\n".join(paragraphs).strip()
    if ext in {".png", ".jpg", ".jpeg", ".webp"}:
        return _ocr_image_bytes(data)

    reader = PdfReader(io.BytesIO(data), strict=False)
    if len(reader.pages) > MAX_PDF_PAGES:
        raise ValueError(f"PDF содержит слишком много страниц (максимум {MAX_PDF_PAGES})")
    extracted = "\n\n".join((page.extract_text() or "") for page in reader.pages).strip()
    # If the PDF contains meaningful selectable text, do not spend resources on OCR.
    if len(re.sub(r"\s+", "", extracted)) >= 80:
        return extracted
    return _ocr_pdf(data, len(reader.pages))


def relevant_passages(text: str, question: str, limit: int = 6) -> list[str]:
    chunks = [x.strip() for x in re.split(r"\n\s*\n|(?<=[.!?])\s+(?=[А-ЯA-Z])", text) if len(x.strip()) > 30]
    terms = {t.lower() for t in re.findall(r"[А-Яа-яЁёA-Za-z0-9]+", question) if len(t) > 3}
    scored = []
    for index, chunk in enumerate(chunks):
        lower = chunk.lower()
        score = sum(1 for t in terms if t in lower)
        if score:
            scored.append((score, -index, chunk))
    scored.sort(reverse=True)
    return [x[2] for x in scored[:limit]] or chunks[: min(limit, len(chunks))]
