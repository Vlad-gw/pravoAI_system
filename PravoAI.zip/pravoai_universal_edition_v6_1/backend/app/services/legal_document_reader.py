from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import date
from typing import Any

import httpx
from bs4 import BeautifulSoup
from sqlalchemy import or_, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.domain.temporal import active_on_date
from app.models.legal import LegalDocument, LegalDocumentVersion
from app.services.ingestion.parser import parse_articles


@dataclass(frozen=True, slots=True)
class KnownLegalDocument:
    key: str
    title: str
    number: str
    aliases: tuple[str, ...]
    official_url: str
    public_url: str
    min_articles: int


KNOWN_DOCUMENTS: tuple[KnownLegalDocument, ...] = (
    KnownLegalDocument(
        key="zpp",
        title="Закон Российской Федерации «О защите прав потребителей»",
        number="2300-1",
        aliases=(
            "закон о защите прав потребителей", "о защите прав потребителей",
            "зозпп", "2300-1", "закон 2300-1",
        ),
        official_url="https://pravo.gov.ru/proxy/ips/?docbody=&nd=102014512",
        public_url="https://www.consultant.ru/document/cons_doc_LAW_305/",
        min_articles=30,
    ),
    KnownLegalDocument(
        key="tk",
        title="Трудовой кодекс Российской Федерации",
        number="197-ФЗ",
        aliases=("трудовой кодекс", "тк рф", "197-фз"),
        official_url="https://pravo.gov.ru/proxy/ips/?docbody=&nd=901807664",
        public_url="https://www.consultant.ru/document/cons_doc_LAW_34683/",
        min_articles=250,
    ),
    KnownLegalDocument(
        key="gk2",
        title="Гражданский кодекс Российской Федерации (часть вторая)",
        number="14-ФЗ",
        aliases=("гражданский кодекс часть вторая", "гражданский кодекс часть 2", "гк рф часть 2", "14-фз"),
        official_url="https://pravo.gov.ru/proxy/ips/?docbody=&nd=102039276",
        public_url="https://www.consultant.ru/document/cons_doc_LAW_9027/",
        min_articles=250,
    ),
)

FULL_TEXT_MARKERS = (
    "полностью", "полный текст", "целиком", "весь текст", "полную версию",
    "текст закона", "покажи закон", "напиши закон", "приведи закон",
)


def detect_full_document_request(question: str) -> KnownLegalDocument | None:
    lower = re.sub(r"\s+", " ", question.lower()).strip()
    if not any(marker in lower for marker in FULL_TEXT_MARKERS):
        return None
    for spec in KNOWN_DOCUMENTS:
        if any(alias in lower for alias in spec.aliases):
            return spec
    return None


def detect_named_document(question: str) -> KnownLegalDocument | None:
    lower = re.sub(r"\s+", " ", question.lower()).strip()
    for spec in KNOWN_DOCUMENTS:
        if any(alias in lower for alias in spec.aliases):
            return spec
    return None


def _clean_html_to_text(html: str) -> str:
    soup = BeautifulSoup(html, "html.parser")
    for tag in soup(["script", "style", "noscript", "svg", "nav", "footer", "header"]):
        tag.decompose()
    return soup.get_text("\n")


def _reconstruct_articles(text: str, *, min_articles: int) -> str | None:
    articles = parse_articles(text)
    if len(articles) < min_articles:
        return None
    return "\n\n".join(a.text.strip() for a in articles if a.text.strip())


async def _fetch_page(url: str) -> str:
    headers = {
        "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 PravoAI/6.1",
        "Accept": "text/html,application/xhtml+xml,text/plain;q=0.9,*/*;q=0.8",
        "Accept-Language": "ru-RU,ru;q=0.9,en;q=0.6",
    }
    async with httpx.AsyncClient(follow_redirects=True, timeout=httpx.Timeout(35.0, connect=10.0), headers=headers) as client:
        response = await client.get(url)
        response.raise_for_status()
        ctype = response.headers.get("content-type", "").lower()
        if "text/plain" in ctype:
            return response.text
        return _clean_html_to_text(response.text)


async def _local_version(db: AsyncSession, spec: KnownLegalDocument, target_date: date) -> LegalDocumentVersion | None:
    stmt = (
        select(LegalDocumentVersion)
        .join(LegalDocument, LegalDocument.id == LegalDocumentVersion.legal_document_id)
        .where(
            or_(LegalDocument.number == spec.number, LegalDocument.title.ilike(f"%{spec.title[:30]}%")),
            active_on_date(LegalDocumentVersion.effective_from, LegalDocumentVersion.effective_to, target_date),
        )
        .order_by(LegalDocumentVersion.effective_from.desc())
        .limit(1)
    )
    return await db.scalar(stmt)


async def get_full_document_text(
    db: AsyncSession,
    *,
    spec: KnownLegalDocument,
    target_date: date,
) -> dict[str, Any]:
    """Return a complete current text when a trusted web source is available.

    The starter corpus is intentionally only a curated snapshot, so it must
    never be mislabeled as the complete statute. For an explicit full-text
    request we first fetch a trusted current public source and verify that the
    page actually contains a realistic number of articles. Only then do we call
    it complete. Network failures fall back to the local snapshot with a clear
    `complete=False` flag.
    """
    errors: list[str] = []
    for label, url in (("официальный портал", spec.official_url), ("КонсультантПлюс", spec.public_url)):
        try:
            raw = await _fetch_page(url)
            text = _reconstruct_articles(raw, min_articles=spec.min_articles)
            if text:
                return {
                    "complete": True,
                    "text": text,
                    "source_url": url,
                    "source_name": label,
                    "document": spec.title,
                    "document_number": spec.number,
                }
            errors.append(f"{label}: структура полного документа не распознана")
        except Exception as exc:
            errors.append(f"{label}: {type(exc).__name__}")

    version = await _local_version(db, spec, target_date)
    if version is not None:
        return {
            "complete": False,
            "text": version.raw_text,
            "source_url": spec.official_url,
            "source_name": "локальный проверенный снимок",
            "document": spec.title,
            "document_number": spec.number,
            "errors": errors,
        }
    return {
        "complete": False,
        "text": "",
        "source_url": spec.official_url,
        "source_name": "официальный портал",
        "document": spec.title,
        "document_number": spec.number,
        "errors": errors,
    }
