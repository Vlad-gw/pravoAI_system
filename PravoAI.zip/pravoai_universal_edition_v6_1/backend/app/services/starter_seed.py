from __future__ import annotations

from app.data.starter_legal_corpus import STARTER_DOCUMENTS
from app.db.session import AsyncSessionLocal
from app.services.ingestion.service import LegalIngestionService


async def ensure_starter_legal_corpus() -> int:
    """Idempotently install/update the local demonstration corpus.

    We no longer return early merely because the database contains documents.
    This allows a newer local build to add corrected starter articles (for
    example, salary-delay provisions) without asking the tester to delete the
    database volume. Production forbids this seed via configuration guardrails.
    """
    async with AsyncSessionLocal() as db:
        service = LegalIngestionService(db)
        changed = 0
        for item in STARTER_DOCUMENTS:
            result = await service.ingest(**item)
            if result.created_document or result.created_version:
                changed += 1
        return changed
