from __future__ import annotations

import hashlib
import math
import re
from typing import Iterable

import httpx

from app.core.config import settings

TOKEN_RE = re.compile(r"[A-Za-zА-Яа-яЁё0-9\.\-]+", re.UNICODE)


def _hash_embedding(text: str, dim: int) -> list[float]:
    """Deterministic emergency fallback used only when no neural provider is available."""
    vec = [0.0] * dim
    tokens = [t.lower() for t in TOKEN_RE.findall(text)]
    for token in tokens:
        digest = hashlib.blake2b(token.encode("utf-8"), digest_size=16).digest()
        idx = int.from_bytes(digest[:8], "big") % dim
        sign = 1.0 if digest[8] % 2 == 0 else -1.0
        vec[idx] += sign * (1.0 + min(len(token), 20) / 20.0)
    norm = math.sqrt(sum(v * v for v in vec)) or 1.0
    return [v / norm for v in vec]


async def _openai_embedding(text: str, *, base_url: str, model: str, api_key: str | None, send_dimensions: bool) -> list[float]:
    payload: dict = {"model": model, "input": text}
    if send_dimensions:
        payload["dimensions"] = settings.embedding_dim
    headers = {"Content-Type": "application/json"}
    if api_key:
        headers["Authorization"] = f"Bearer {api_key}"
    async with httpx.AsyncClient(timeout=90) as client:
        response = await client.post(f"{base_url.rstrip('/')}/embeddings", headers=headers, json=payload)
        response.raise_for_status()
        data = response.json()["data"][0]["embedding"]
    if len(data) != settings.embedding_dim:
        raise RuntimeError(f"Embedding dimension {len(data)} != EMBEDDING_DIM={settings.embedding_dim}")
    return data


async def embed_text(text: str) -> list[float]:
    embedding_key = settings.embedding_api_key or settings.llm_api_key
    embedding_base = settings.embedding_base_url or settings.llm_base_url

    if settings.embedding_provider in {"auto", "openai_compatible"} and embedding_key:
        try:
            return await _openai_embedding(
                text,
                base_url=embedding_base,
                model=settings.embedding_model,
                api_key=embedding_key,
                send_dimensions=settings.embedding_send_dimensions,
            )
        except Exception:
            if settings.embedding_provider == "openai_compatible":
                raise

    if settings.embedding_provider in {"auto", "ollama"}:
        try:
            return await _openai_embedding(
                text,
                base_url=settings.ollama_base_url,
                model=settings.ollama_embedding_model,
                api_key=None,
                send_dimensions=True,
            )
        except Exception:
            if settings.embedding_provider == "ollama":
                raise

    return _hash_embedding(text, settings.embedding_dim)


async def embed_many(texts: Iterable[str]) -> list[list[float]]:
    result: list[list[float]] = []
    for text in texts:
        result.append(await embed_text(text))
    return result
