from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import date
from uuid import UUID

from sqlalchemy import desc, func, or_, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.domain.temporal import active_on_date
from app.models.legal import LegalChunk, LegalDocument, LegalDocumentVersion


@dataclass(slots=True)
class SearchHit:
    chunk_id: UUID
    document_id: UUID
    document_title: str
    document_number: str | None
    article: str | None
    part: str | None
    text: str
    effective_from: date
    effective_to: date | None
    source_url: str
    source_name: str
    score: float
    is_snapshot: bool = False
    verified_as_of: str | None = None


# Areas are deliberately restrictive. The previous MVP merely boosted a legal
# area, so a labour-law question could surface consumer-law/GK chunks in the
# source panel. For a user-facing legal product cross-domain recall is less
# important than avoiding irrelevant authorities. Additional documents can be
# added to each area as the production corpus grows.
AREA_DOC_HINTS: dict[str, list[str]] = {
    "трудовое право": ["трудовой"],
    "защита прав потребителей": ["потребител", "гражданск"],
    "жилищное и гражданское право": ["гражданск", "жилищн"],
    "семейное право": ["семейн", "гражданск"],
    "административное право": ["коап", "административ"],
    "уголовное право": ["уголовн", "упк"],
}

STOPWORDS = {
    "когда", "куда", "какой", "какая", "какие", "что", "чтобы", "если", "или",
    "это", "как", "для", "при", "уже", "меня", "мне", "моей", "мою", "мой",
    "свою", "свой", "два", "две", "месяца", "месяц", "день", "дней", "года",
    "работодатель", "работник",  # area terms are handled separately
}

SYNONYM_GROUPS = [
    (["зарплат", "заработн", "не выплат", "невыплат", "задерж"],
     "заработная плата сроки выплаты задержка компенсация невыплата"),
    (["увол", "по собствен", "принуж", "застав"],
     "увольнение расторжение трудового договора инициатива работника заявление отзыв"),
    (["сокращ", "сократили", "штат", "фиктивн", "нового сотрудника"],
     "сокращение штата реальность сокращения вакантные должности преимущественное право восстановление на работе"),
    (["возврат", "вернуть", "товар"],
     "возврат обмен товар потребитель продавец недостаток дистанционная продажа"),
    (["не тот", "не ту", "другой цвет", "другой размер", "другой артикул", "привез", "достав", "заказ"],
     "ассортимент цвет размер модель артикул соответствие договору заказу замена отказ возврат"),
    (["аренд", "найм", "квартир"],
     "наем жилого помещения наниматель наймодатель расторжение"),
]


def expand_query(query: str) -> str:
    lower = query.lower()
    additions: list[str] = []
    for triggers, expansion in SYNONYM_GROUPS:
        if any(t in lower for t in triggers):
            additions.append(expansion)
    article = re.search(r"(?:ст\.?|статья)\s*(\d+(?:\.\d+)?)", lower)
    if article:
        additions.append(f"статья {article.group(1)}")
    return (query + " " + " ".join(additions)).strip()


def _meaningful_terms(text: str) -> set[str]:
    words = re.findall(r"[А-Яа-яЁёA-Za-z0-9.]+", text.lower())
    return {w for w in words if len(w) > 3 and w not in STOPWORDS}


def _scenario_article_hints(query: str, legal_area: str | None) -> set[str]:
    q = query.lower()
    if legal_area == "трудовое право":
        if "пенси" in q and any(x in q for x in ["пособ", "выплат", "расчет", "увол"]):
            return {"127", "140", "178", "236", "392"}
        if any(x in q for x in ["зарплат", "заработн"]) and any(x in q for x in ["не плат", "не выплат", "задерж", "долг"]):
            return {"136", "142", "236", "352", "356", "392"}
        if any(x in q for x in ["сокращ", "сократили", "сокращению", "штата", "штат"]):
            return {"62", "81", "178", "179", "180", "261", "392", "393", "394"}
        if "увол" in q and any(x in q for x in ["застав", "принуж", "по собствен", "давят"]):
            return {"80", "352", "356", "392"}
        if "увол" in q and any(x in q for x in ["хочу", "сам", "собствен", "уйти", "увольняюсь"]):
            return {"80", "84.1", "127", "140"}
    if legal_area == "защита прав потребителей":
        if any(x in q for x in ["не тот", "не ту", "другой цвет", "другого цвета", "другой размер", "другой артикул", "не соответствует заказ", "привез", "достав"]):
            return {"4", "18", "21", "22", "26.1", "467", "468", "469"}
        if any(x in q for x in ["интернет", "онлайн", "маркетплейс", "дистанц", "сайт", "приложен"]):
            return {"26.1", "4", "18", "22", "497"}
        if any(x in q for x in ["брак", "недостат", "слом", "неисправ", "некачеств"]):
            return {"4", "18", "21", "22", "23", "469", "475"}
        if any(x in q for x in ["не возвращ", "не вернул", "не вернули", "возврат денег", "вернуть деньги"]):
            return {"13", "17", "18", "22", "23", "25", "26.1"}
        if any(x in q for x in ["вернуть", "возврат", "обмен"]):
            return {"25", "26.1", "18", "22"}
    if legal_area == "жилищное и гражданское право" and any(x in q for x in ["аренд", "найм", "квартир"]):
        return {"671", "687"}
    return set()


class HybridLegalSearch:
    """Hybrid retrieval with temporal validity and domain/relevance gates.

    Important product behaviour:
    * target-date filtering is mandatory;
    * when an area is confidently classified, candidates are restricted to
      documents appropriate for that area;
    * hash embeddings are only a fallback and can never flood visible sources;
    * top results are deduplicated by article for a concise citation panel.
    """

    def __init__(self, session: AsyncSession, *, rrf_k: int = 60, candidate_k: int = 60):
        self.session = session
        self.rrf_k = rrf_k
        self.candidate_k = candidate_k

    async def search(
        self,
        *,
        query: str,
        query_embedding: list[float],
        target_date: date,
        top_k: int = 8,
        legal_area: str | None = None,
    ) -> list[SearchHit]:
        expanded = expand_query(query)
        semantic_rows = await self._semantic(query_embedding=query_embedding, target_date=target_date, legal_area=legal_area)
        lexical_rows = await self._lexical(query=expanded, target_date=target_date, legal_area=legal_area)
        article_hints = _scenario_article_hints(query, legal_area)
        pinned_rows = await self._articles(articles=article_hints, target_date=target_date, legal_area=legal_area) if article_hints else []

        scores: dict[UUID, float] = {}
        row_by_id: dict[UUID, tuple] = {}
        lexical_ids = {row.id for row in lexical_rows}
        semantic_weight = 0.18 if settings.embedding_provider == "hash" else 0.95
        lexical_weight = 2.5

        for rank, row in enumerate(semantic_rows, start=1):
            row_by_id[row.id] = row
            weight = semantic_weight if (not lexical_rows or row.id in lexical_ids) else semantic_weight * 0.15
            scores[row.id] = scores.get(row.id, 0.0) + weight / (self.rrf_k + rank)

        for rank, row in enumerate(lexical_rows, start=1):
            row_by_id[row.id] = row
            scores[row.id] = scores.get(row.id, 0.0) + lexical_weight / (self.rrf_k + rank)

        # Exact scenario articles are pinned in addition to semantic/lexical retrieval.
        # This is important for legal QA: a semantically similar but legally wrong
        # article must never crowd out the statute that directly governs the case.
        for row in pinned_rows:
            row_by_id[row.id] = row
            scores[row.id] = scores.get(row.id, 0.0) + 0.55

        qterms = _meaningful_terms(expanded)
        requested_article_match = re.search(r"(?:ст\.?|статья)\s*(\d+(?:\.\d+)?)", query.lower())
        requested_article = requested_article_match.group(1) if requested_article_match else None

        relevance: dict[UUID, int] = {}
        for chunk_id, row in row_by_id.items():
            text_lower = row.text.lower()
            overlap_terms = {term for term in qterms if term in text_lower}
            relevance[chunk_id] = len(overlap_terms)
            scores[chunk_id] = scores.get(chunk_id, 0.0) + min(len(overlap_terms), 10) * 0.008
            if row.article and row.article in article_hints:
                scores[chunk_id] += 0.18
            if requested_article and row.article == requested_article:
                scores[chunk_id] += 0.40

        ranked_ids = sorted(scores, key=scores.get, reverse=True)

        # In local hash mode, lexical evidence is required whenever it exists.
        if settings.embedding_provider == "hash" and lexical_rows:
            ranked_ids = [cid for cid in ranked_ids if cid in lexical_ids]

        # Remove weak generic results that share no meaningful term and have no
        # scenario/article signal. This is what prevents an unrelated consumer
        # article from appearing for a salary query.
        filtered: list[UUID] = []
        for cid in ranked_ids:
            row = row_by_id[cid]
            strong_article = bool(row.article and row.article in article_hints)
            exact_article = bool(requested_article and row.article == requested_article)
            if relevance.get(cid, 0) == 0 and not strong_article and not exact_article:
                continue
            filtered.append(cid)

        # One best chunk per article keeps the source panel short and auditable.
        chosen: list[UUID] = []
        seen: set[tuple[UUID, str | None]] = set()
        for cid in filtered:
            row = row_by_id[cid]
            key = (row.document_id, row.article)
            if key in seen:
                continue
            seen.add(key)
            chosen.append(cid)
            if len(chosen) >= top_k:
                break

        out: list[SearchHit] = []
        for cid in chosen:
            row = row_by_id[cid]
            meta = row.version_metadata or {}
            out.append(SearchHit(
                chunk_id=row.id,
                document_id=row.document_id,
                document_title=row.document_title,
                document_number=row.document_number,
                article=row.article,
                part=row.part,
                text=row.text,
                effective_from=row.effective_from,
                effective_to=row.effective_to,
                source_url=row.source_url,
                source_name=row.source_name,
                score=scores[cid],
                is_snapshot=bool(meta.get("starter_snapshot")),
                verified_as_of=meta.get("verified_as_of"),
            ))
        return out

    def _base_select(self):
        return (
            select(
                LegalChunk.id.label("id"),
                LegalDocument.id.label("document_id"),
                LegalDocument.title.label("document_title"),
                LegalDocument.number.label("document_number"),
                LegalDocument.source_url.label("source_url"),
                LegalDocument.source_name.label("source_name"),
                LegalChunk.article.label("article"),
                LegalChunk.part.label("part"),
                LegalChunk.text.label("text"),
                LegalDocumentVersion.effective_from.label("effective_from"),
                LegalDocumentVersion.effective_to.label("effective_to"),
                LegalDocumentVersion.metadata_json.label("version_metadata"),
            )
            .join(LegalDocumentVersion, LegalDocumentVersion.id == LegalChunk.version_id)
            .join(LegalDocument, LegalDocument.id == LegalDocumentVersion.legal_document_id)
        )

    def _area_clause(self, legal_area: str | None):
        hints = AREA_DOC_HINTS.get(legal_area or "")
        if not hints:
            return None
        return or_(*[func.lower(LegalDocument.title).like(f"%{hint.lower()}%") for hint in hints])

    async def _articles(self, *, articles: set[str], target_date: date, legal_area: str | None):
        """Fetch active chunks for scenario-critical article numbers.

        The normal hybrid ranker is still used, but these rows are guaranteed to
        enter the candidate set.  This prevents a common legal-RAG failure where
        a nearby article outranks the provision that actually creates the right.
        """
        if not articles:
            return []
        stmt = self._base_select().where(
            LegalChunk.article.in_(sorted(articles)),
            active_on_date(LegalDocumentVersion.effective_from, LegalDocumentVersion.effective_to, target_date),
        )
        area_clause = self._area_clause(legal_area)
        if area_clause is not None:
            stmt = stmt.where(area_clause)
        return list((await self.session.execute(stmt.limit(max(40, len(articles) * 4)))).all())

    async def _semantic(self, *, query_embedding: list[float], target_date: date, legal_area: str | None):
        stmt = self._base_select().where(
            LegalChunk.embedding.is_not(None),
            active_on_date(LegalDocumentVersion.effective_from, LegalDocumentVersion.effective_to, target_date),
        )
        area_clause = self._area_clause(legal_area)
        if area_clause is not None:
            stmt = stmt.where(area_clause)
        stmt = stmt.order_by(LegalChunk.embedding.cosine_distance(query_embedding)).limit(self.candidate_k)
        return list((await self.session.execute(stmt)).all())

    async def _lexical(self, *, query: str, target_date: date, legal_area: str | None):
        terms = [t for t in re.findall(r"[А-Яа-яЁёA-Za-z0-9.]+", query.lower()) if len(t) > 3]
        unique = list(dict.fromkeys(terms))[:28]
        if not unique:
            return []
        search_expr = " OR ".join(f'"{t}"' for t in unique)
        ts_query = func.websearch_to_tsquery("russian", search_expr)
        rank = func.ts_rank_cd(LegalChunk.search_tsv, ts_query)
        stmt = self._base_select().where(
            LegalChunk.search_tsv.op("@@")(ts_query),
            active_on_date(LegalDocumentVersion.effective_from, LegalDocumentVersion.effective_to, target_date),
        )
        area_clause = self._area_clause(legal_area)
        if area_clause is not None:
            stmt = stmt.where(area_clause)
        stmt = stmt.order_by(desc(rank)).limit(self.candidate_k)
        return list((await self.session.execute(stmt)).all())
