from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

from sqlalchemy import desc, select

from app.core.config import settings
from app.db.session import AsyncSessionLocal
from app.models.app import IngestionJob
from app.models.legal import LegalDocument, LegalDocumentVersion
from app.services.ingestion.source_client import fetch_official_text


async def run_corpus_watch() -> dict:
    path = Path(settings.corpus_manifest_path)
    if not path.exists():
        return {"checked": 0, "changed": 0, "errors": ["manifest not found"]}
    manifest = json.loads(path.read_text(encoding="utf-8"))
    job = IngestionJob(source_name="official-corpus-watch", status="running", details_json={})
    async with AsyncSessionLocal() as db:
        db.add(job)
        await db.flush()
        checked = 0
        changed = 0
        errors: list[dict] = []
        updates: list[dict] = []
        for item in manifest:
            if not item.get("enabled", True):
                continue
            checked += 1
            try:
                text = (await fetch_official_text(item["url"])).strip()
                digest = hashlib.sha256(text.encode("utf-8")).hexdigest()
                doc = await db.scalar(
                    select(LegalDocument).where(
                        (LegalDocument.number == item.get("number")) | (LegalDocument.title == item.get("title"))
                    ).limit(1)
                )
                latest_hash = None
                if doc:
                    latest = await db.scalar(
                        select(LegalDocumentVersion)
                        .where(LegalDocumentVersion.legal_document_id == doc.id)
                        .order_by(desc(LegalDocumentVersion.effective_from))
                        .limit(1)
                    )
                    latest_hash = latest.content_hash if latest else None
                is_changed = latest_hash != digest
                if is_changed:
                    changed += 1
                updates.append({
                    "title": item.get("title"), "number": item.get("number"), "url": item.get("url"),
                    "changed": is_changed, "remote_hash": digest, "indexed_hash": latest_hash,
                    "requires_review": is_changed,
                })
            except Exception as exc:
                errors.append({"title": item.get("title"), "error": str(exc)[:500]})
        job.status = "success" if not errors else "partial"
        job.documents_found = checked
        job.details_json = {
            "checked": checked,
            "changed": changed,
            "updates": updates,
            "errors": errors,
            "note": "Изменения только обнаруживаются. Автоматическая подмена редакции запрещена: администратор должен подтвердить дату вступления новой редакции в силу.",
        }
        job.finished_at = datetime.now(timezone.utc)
        await db.commit()
        return job.details_json
