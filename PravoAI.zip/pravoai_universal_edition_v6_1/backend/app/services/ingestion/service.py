from __future__ import annotations

import hashlib
from dataclasses import dataclass
from datetime import date

from sqlalchemy import delete, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.legal import LegalChunk, LegalDocument, LegalDocumentVersion
from app.services.ingestion.parser import parse_to_chunks
from app.services.embeddings import embed_many


@dataclass(slots=True)
class IngestionResult:
    document_id: str
    version_id: str
    created_document: bool
    created_version: bool
    chunks_count: int


class LegalIngestionService:
    def __init__(self, session: AsyncSession):
        self.session = session

    async def ingest(
        self,
        *,
        raw_text: str,
        document_type: str,
        title: str,
        short_title: str | None,
        number: str | None,
        adoption_date: date | None,
        source_name: str,
        source_url: str,
        external_id: str,
        effective_from: date,
        revision_date: date | None,
        publication_date: date | None,
        metadata: dict | None = None,
    ) -> IngestionResult:
        normalized_raw = raw_text.strip()
        if not normalized_raw:
            raise ValueError("Пустой текст нормативного акта")

        chunks = parse_to_chunks(normalized_raw)
        if not chunks:
            raise ValueError("Не удалось обнаружить в документе заголовки вида 'Статья N'")

        content_hash = hashlib.sha256(normalized_raw.encode("utf-8")).hexdigest()
        embeddings = await embed_many([chunk.text for chunk in chunks])
        document = await self.session.scalar(
            select(LegalDocument).where(LegalDocument.external_id == external_id)
        )
        created_document = document is None
        if document is None:
            document = LegalDocument(
                document_type=document_type,
                title=title,
                short_title=short_title,
                number=number,
                adoption_date=adoption_date,
                source_name=source_name,
                source_url=source_url,
                external_id=external_id,
            )
            self.session.add(document)
            await self.session.flush()
        else:
            # Metadata may improve over time without changing legal version identity.
            document.document_type = document_type
            document.title = title
            document.short_title = short_title
            document.number = number
            document.adoption_date = adoption_date
            document.source_name = source_name
            document.source_url = source_url

        version = await self.session.scalar(
            select(LegalDocumentVersion).where(
                LegalDocumentVersion.legal_document_id == document.id,
                LegalDocumentVersion.content_hash == content_hash,
            )
        )
        created_version = version is None
        if version is None:
            version = LegalDocumentVersion(
                legal_document_id=document.id,
                revision_date=revision_date,
                publication_date=publication_date,
                effective_from=effective_from,
                effective_to=None,
                raw_text=normalized_raw,
                content_hash=content_hash,
                metadata_json=metadata or {},
            )
            self.session.add(version)
            await self.session.flush()

            for chunk, embedding in zip(chunks, embeddings):
                self.session.add(
                    LegalChunk(
                        version_id=version.id,
                        chapter=chunk.chapter,
                        article=chunk.article,
                        part=chunk.part,
                        paragraph=None,
                        text=chunk.text,
                        parent_text=chunk.parent_text,
                        metadata_json={
                            **chunk.metadata,
                            "source_url": source_url,
                            "source_name": source_name,
                            "document_title": title,
                            "document_number": number,
                            "effective_from": effective_from.isoformat(),
                        },
                        embedding=embedding,
                    )
                )
        else:
            # If a previous failed/dev run created version without chunks, repair it.
            existing_chunk = await self.session.scalar(
                select(LegalChunk.id).where(LegalChunk.version_id == version.id).limit(1)
            )
            if existing_chunk is None:
                await self.session.execute(delete(LegalChunk).where(LegalChunk.version_id == version.id))
                for chunk, embedding in zip(chunks, embeddings):
                    self.session.add(
                        LegalChunk(
                            version_id=version.id,
                            chapter=chunk.chapter,
                            article=chunk.article,
                            part=chunk.part,
                            paragraph=None,
                            text=chunk.text,
                            parent_text=chunk.parent_text,
                            metadata_json=chunk.metadata,
                            embedding=embedding,
                        )
                    )

        await self.session.flush()
        await self._rebuild_temporal_chain(document.id)
        await self.session.commit()

        return IngestionResult(
            document_id=str(document.id),
            version_id=str(version.id),
            created_document=created_document,
            created_version=created_version,
            chunks_count=len(chunks),
        )

    async def _rebuild_temporal_chain(self, document_id) -> None:
        versions = list(
            (
                await self.session.scalars(
                    select(LegalDocumentVersion)
                    .where(LegalDocumentVersion.legal_document_id == document_id)
                    .order_by(LegalDocumentVersion.effective_from.asc(), LegalDocumentVersion.created_at.asc())
                )
            ).all()
        )
        for index, version in enumerate(versions):
            version.effective_to = (
                versions[index + 1].effective_from if index + 1 < len(versions) else None
            )
