from __future__ import annotations

from urllib.parse import urljoin, urlparse

import httpx
from bs4 import BeautifulSoup


ALLOWED_LEGAL_HOSTS = {
    "pravo.gov.ru",
    "www.pravo.gov.ru",
    "ips.pravo.gov.ru",
    "publication.pravo.gov.ru",
}


class LegalSourceError(ValueError):
    pass


def validate_official_url(url: str) -> None:
    parsed = urlparse(url)
    if parsed.scheme != "https":
        raise LegalSourceError("Разрешены только HTTPS-ссылки на официальные источники")
    if parsed.username or parsed.password:
        raise LegalSourceError("URL с учетными данными запрещен")
    if parsed.port not in (None, 443):
        raise LegalSourceError("Разрешен только стандартный HTTPS-порт")
    if parsed.hostname not in ALLOWED_LEGAL_HOSTS:
        raise LegalSourceError("Источник не входит в allowlist официальных правовых доменов")


async def fetch_official_text(url: str) -> str:
    """Fetch an official source without allowing redirect-based SSRF.

    Every redirect target is revalidated against the same legal-domain allowlist.
    """
    validate_official_url(url)
    headers = {
        "User-Agent": "PravoAI/1.0 (+legal-research; contact=admin@localhost)",
        "Accept": "text/html,application/xhtml+xml,text/plain;q=0.9,*/*;q=0.8",
    }
    current = url
    async with httpx.AsyncClient(follow_redirects=False, timeout=35.0, headers=headers) as client:
        for _ in range(6):
            validate_official_url(current)
            response = await client.get(current)
            if response.status_code in {301, 302, 303, 307, 308}:
                location = response.headers.get("location")
                if not location:
                    raise LegalSourceError("Источник вернул редирект без Location")
                current = urljoin(current, location)
                continue
            response.raise_for_status()
            break
        else:
            raise LegalSourceError("Слишком много редиректов при загрузке источника")

    content_type = response.headers.get("content-type", "").lower()
    if "text/plain" in content_type:
        return response.text
    if "application/pdf" in content_type:
        raise LegalSourceError("URL ведет на PDF. Для сканов/официальных PDF используйте импорт файла после извлечения текста/OCR.")

    soup = BeautifulSoup(response.text, "html.parser")
    for tag in soup(["script", "style", "noscript", "svg"]):
        tag.decompose()
    return soup.get_text("\n")
