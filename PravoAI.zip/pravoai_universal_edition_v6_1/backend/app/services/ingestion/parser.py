from __future__ import annotations

import re
from dataclasses import dataclass, field


ARTICLE_RE = re.compile(r"^\s*Статья\s+([0-9]+(?:\s+[0-9]+|(?:\.[0-9]+))*)[\.:]?\s*(.*)$", re.IGNORECASE)
CHAPTER_RE = re.compile(r"^\s*(?:ГЛАВА|Глава)\s+([IVXLCDM0-9]+)[\.:]?\s*(.*)$")
PART_RE = re.compile(r"^\s*(\d+(?:\.\d+)*)\.\s+(.+)$")


@dataclass(slots=True)
class ParsedArticle:
    article: str
    title: str | None
    chapter: str | None
    text: str


@dataclass(slots=True)
class ParsedChunk:
    article: str
    chapter: str | None
    part: str | None
    text: str
    parent_text: str | None
    metadata: dict = field(default_factory=dict)


def normalize_text(raw: str) -> str:
    raw = raw.replace("\xa0", " ").replace("\r\n", "\n").replace("\r", "\n")
    lines: list[str] = []
    for line in raw.split("\n"):
        line = re.sub(r"[ \t]+", " ", line).strip()
        lines.append(line)

    # Preserve structural line breaks, collapse excessive blank lines.
    result: list[str] = []
    blank = False
    for line in lines:
        if not line:
            if not blank:
                result.append("")
            blank = True
        else:
            result.append(line)
            blank = False
    return "\n".join(result).strip()


def normalize_article_number(value: str) -> str:
    # Official texts may render superscript article numbers as "42 2".
    return ".".join(value.split())


def parse_articles(raw_text: str) -> list[ParsedArticle]:
    text = normalize_text(raw_text)
    lines = text.splitlines()

    current_chapter: str | None = None
    current_article: str | None = None
    current_title: str | None = None
    buffer: list[str] = []
    articles: list[ParsedArticle] = []

    def flush() -> None:
        nonlocal current_article, current_title, buffer
        if current_article is None:
            return
        body = "\n".join(buffer).strip()
        full = f"Статья {current_article}"
        if current_title:
            full += f". {current_title}"
        if body:
            full += f"\n\n{body}"
        articles.append(
            ParsedArticle(
                article=current_article,
                title=current_title,
                chapter=current_chapter,
                text=full,
            )
        )
        buffer = []

    for line in lines:
        chapter_match = CHAPTER_RE.match(line)
        if chapter_match:
            # A chapter heading starts a new structural parent. If it appears
            # after an article body, finish that article before switching chapter.
            flush()
            current_article = None
            current_title = None
            number, title = chapter_match.groups()
            current_chapter = f"Глава {number}" + (f". {title}" if title else "")
            continue

        article_match = ARTICLE_RE.match(line)
        if article_match:
            flush()
            number, title = article_match.groups()
            current_article = normalize_article_number(number)
            current_title = title.strip() or None
            buffer = []
            continue

        if current_article is not None:
            buffer.append(line)

    flush()
    return articles


def article_to_chunks(article: ParsedArticle, max_chars: int = 6000) -> list[ParsedChunk]:
    if len(article.text) <= max_chars:
        return [
            ParsedChunk(
                article=article.article,
                chapter=article.chapter,
                part=None,
                text=article.text,
                parent_text=None,
                metadata={"article_title": article.title},
            )
        ]

    lines = article.text.splitlines()
    header: list[str] = []
    sections: list[tuple[str | None, list[str]]] = []
    current_part: str | None = None
    current_lines: list[str] = []

    for index, line in enumerate(lines):
        if index == 0 or (index == 1 and not line.strip()):
            header.append(line)
            continue
        part_match = PART_RE.match(line)
        if part_match:
            if current_lines:
                sections.append((current_part, current_lines))
            current_part = part_match.group(1)
            current_lines = [line]
        else:
            current_lines.append(line)
    if current_lines:
        sections.append((current_part, current_lines))

    if not sections:
        # Safe fallback for unusually formatted giant articles.
        body = article.text
        return [
            ParsedChunk(
                article=article.article,
                chapter=article.chapter,
                part=str(i + 1),
                text=body[i : i + max_chars],
                parent_text=article.text[:1200],
                metadata={"article_title": article.title, "fallback_split": True},
            )
            for i in range(0, len(body), max_chars)
        ]

    chunks: list[ParsedChunk] = []
    current: list[str] = []
    current_parts: list[str] = []
    header_text = "\n".join(header).strip()

    def emit() -> None:
        nonlocal current, current_parts
        if not current:
            return
        body = "\n".join(current).strip()
        text = f"{header_text}\n\n{body}" if header_text else body
        chunks.append(
            ParsedChunk(
                article=article.article,
                chapter=article.chapter,
                part=",".join(current_parts) or None,
                text=text,
                parent_text=article.text[:1600],
                metadata={"article_title": article.title},
            )
        )
        current = []
        current_parts = []

    for part_number, section_lines in sections:
        section_text = "\n".join(section_lines).strip()
        projected = len("\n".join(current)) + len(section_text) + len(header_text) + 4
        if current and projected > max_chars:
            emit()
        current.extend(section_lines)
        if part_number:
            current_parts.append(part_number)
    emit()
    return chunks


def parse_to_chunks(raw_text: str, max_chars: int = 6000) -> list[ParsedChunk]:
    chunks: list[ParsedChunk] = []
    for article in parse_articles(raw_text):
        chunks.extend(article_to_chunks(article, max_chars=max_chars))
    return chunks
