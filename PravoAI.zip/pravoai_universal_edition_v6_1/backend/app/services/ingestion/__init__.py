"""Ingestion subsystem for official legal sources."""
