from sqlalchemy import select

from app.core.config import settings
from app.core.security import hash_password
from app.db.session import AsyncSessionLocal
from app.models.app import User


async def ensure_bootstrap_admin() -> None:
    async with AsyncSessionLocal() as db:
        existing = await db.scalar(select(User).where(User.email == settings.bootstrap_admin_email.lower()))
        if existing is None:
            db.add(User(
                email=settings.bootstrap_admin_email.lower(),
                password_hash=hash_password(settings.bootstrap_admin_password),
                full_name="Администратор ПравоAI",
                role="admin",
            ))
            await db.commit()
