from __future__ import annotations

import asyncio
import struct

from app.core.config import settings


class AntivirusUnavailable(RuntimeError):
    pass


class MalwareDetected(ValueError):
    pass


async def scan_bytes(data: bytes) -> None:
    """Scan bytes with clamd INSTREAM protocol when configured.

    Local development can leave ClamAV disabled. Commercial production should
    set ANTIVIRUS_REQUIRED=true and CLAMAV_HOST=clamav; a scanner outage then
    fails closed instead of accepting unscanned customer documents.
    """
    if not settings.clamav_host:
        if settings.antivirus_required:
            raise AntivirusUnavailable("Антивирусный сканер не настроен")
        return
    try:
        reader, writer = await asyncio.wait_for(
            asyncio.open_connection(settings.clamav_host, settings.clamav_port), timeout=5
        )
        writer.write(b"zINSTREAM\0")
        for offset in range(0, len(data), 64 * 1024):
            chunk = data[offset : offset + 64 * 1024]
            writer.write(struct.pack("!I", len(chunk)))
            writer.write(chunk)
        writer.write(struct.pack("!I", 0))
        await writer.drain()
        result = await asyncio.wait_for(reader.read(4096), timeout=30)
        writer.close()
        await writer.wait_closed()
    except (OSError, asyncio.TimeoutError) as exc:
        if settings.antivirus_required:
            raise AntivirusUnavailable("Антивирусный сканер временно недоступен") from exc
        return

    text = result.decode("utf-8", errors="replace")
    if "FOUND" in text:
        raise MalwareDetected("Файл отклонен антивирусной проверкой")
    if "OK" not in text and settings.antivirus_required:
        raise AntivirusUnavailable("Антивирус не подтвердил безопасность файла")
