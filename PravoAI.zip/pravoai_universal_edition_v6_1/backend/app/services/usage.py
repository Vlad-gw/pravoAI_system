from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone

from fastapi import HTTPException
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.models.app import GeneratedDocument, Message, UploadedDocument, User, Conversation


@dataclass(frozen=True)
class PlanLimits:
    questions: int
    documents: int
    generations: int


def limits_for(plan: str) -> PlanLimits:
    if plan == "business":
        return PlanLimits(settings.business_questions_month, settings.business_documents_month, settings.business_generations_month)
    if plan == "pro":
        return PlanLimits(settings.pro_questions_month, settings.pro_documents_month, settings.pro_generations_month)
    return PlanLimits(settings.free_questions_month, settings.free_documents_month, settings.free_generations_month)


def month_start() -> datetime:
    now = datetime.now(timezone.utc)
    return datetime(now.year, now.month, 1, tzinfo=timezone.utc)


async def usage_for(db: AsyncSession, user: User) -> dict:
    from app.services.billing import sync_subscription
    await sync_subscription(db, user)
    since = month_start()
    questions = int((await db.scalar(
        select(func.count(Message.id))
        .join(Conversation, Conversation.id == Message.conversation_id)
        .where(Conversation.user_id == user.id, Message.role == "user", Message.created_at >= since)
    )) or 0)
    documents = int((await db.scalar(
        select(func.count(UploadedDocument.id)).where(UploadedDocument.user_id == user.id, UploadedDocument.created_at >= since)
    )) or 0)
    generations = int((await db.scalar(
        select(func.count(GeneratedDocument.id)).where(GeneratedDocument.user_id == user.id, GeneratedDocument.created_at >= since)
    )) or 0)
    limits = limits_for(user.plan)
    return {
        "plan": user.plan,
        "period_start": since.isoformat(),
        "questions": {"used": questions, "limit": limits.questions},
        "documents": {"used": documents, "limit": limits.documents},
        "generations": {"used": generations, "limit": limits.generations},
    }


async def enforce_quota(db: AsyncSession, user: User, feature: str) -> None:
    if user.role == "admin":
        return
    usage = await usage_for(db, user)
    entry = usage.get(feature)
    if not entry:
        return
    if entry["used"] >= entry["limit"]:
        raise HTTPException(
            status_code=402,
            detail=f"Лимит тарифа исчерпан: {entry['limit']} {feature} в месяц. Перейдите на более высокий тариф.",
        )
