from __future__ import annotations

from datetime import datetime, timedelta, timezone
import hashlib
import secrets

from sqlalchemy import select, update
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.app import EmailToken


def token_hash(raw: str) -> str:
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


async def create_email_token(db: AsyncSession, user_id, purpose: str, ttl: timedelta) -> str:
    now = datetime.now(timezone.utc)
    await db.execute(
        update(EmailToken)
        .where(EmailToken.user_id == user_id, EmailToken.purpose == purpose, EmailToken.used_at.is_(None))
        .values(used_at=now)
    )
    raw = secrets.token_urlsafe(40)
    db.add(EmailToken(user_id=user_id, purpose=purpose, token_hash=token_hash(raw), expires_at=now + ttl))
    await db.flush()
    return raw


async def consume_email_token(db: AsyncSession, raw: str, purpose: str) -> EmailToken | None:
    now = datetime.now(timezone.utc)
    row = await db.scalar(
        select(EmailToken).where(
            EmailToken.token_hash == token_hash(raw),
            EmailToken.purpose == purpose,
            EmailToken.used_at.is_(None),
            EmailToken.expires_at > now,
        )
    )
    if row is None:
        return None
    row.used_at = now
    await db.flush()
    return row
