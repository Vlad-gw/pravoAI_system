from __future__ import annotations

import asyncio
import html
import smtplib
from email.message import EmailMessage

from app.core.config import settings


class EmailDeliveryError(RuntimeError):
    pass


def _send_sync(to_email: str, subject: str, text: str, html_body: str | None = None) -> None:
    if settings.email_provider != "smtp":
        raise EmailDeliveryError("SMTP-провайдер не настроен")
    msg = EmailMessage()
    msg["Subject"] = subject
    msg["From"] = f"{settings.smtp_from_name} <{settings.smtp_from_email}>" if settings.smtp_from_name else settings.smtp_from_email
    msg["To"] = to_email
    msg.set_content(text)
    if html_body:
        msg.add_alternative(html_body, subtype="html")

    with smtplib.SMTP(settings.smtp_host, settings.smtp_port, timeout=20) as smtp:
        smtp.ehlo()
        if settings.smtp_starttls:
            smtp.starttls()
            smtp.ehlo()
        if settings.smtp_username:
            smtp.login(settings.smtp_username, settings.smtp_password)
        smtp.send_message(msg)


async def send_email(to_email: str, subject: str, text: str, html_body: str | None = None) -> None:
    await asyncio.to_thread(_send_sync, to_email, subject, text, html_body)


def verification_message(raw_token: str) -> tuple[str, str, str]:
    url = f"{settings.public_url.rstrip('/')}/?verify_token={raw_token}"
    subject = "Подтвердите email в ПравоAI"
    text = f"Подтвердите email, открыв ссылку: {url}\n\nСсылка действует {settings.verification_token_hours} ч."
    body = f"<p>Подтвердите email для ПравоAI.</p><p><a href=\"{html.escape(url, quote=True)}\">Подтвердить email</a></p><p>Ссылка действует {settings.verification_token_hours} ч.</p>"
    return subject, text, body


def reset_message(raw_token: str) -> tuple[str, str, str]:
    url = f"{settings.public_url.rstrip('/')}/?reset_token={raw_token}"
    subject = "Сброс пароля ПравоAI"
    text = f"Для смены пароля откройте ссылку: {url}\n\nСсылка действует {settings.password_reset_token_minutes} мин. Если вы не запрашивали сброс, проигнорируйте письмо."
    body = f"<p>Для смены пароля ПравоAI откройте ссылку ниже.</p><p><a href=\"{html.escape(url, quote=True)}\">Сменить пароль</a></p><p>Ссылка действует {settings.password_reset_token_minutes} мин.</p>"
    return subject, text, body
