from __future__ import annotations

from datetime import datetime, timedelta, timezone
from decimal import Decimal
import uuid

import httpx
from fastapi import HTTPException
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.models.app import Payment, Subscription, User


PLANS = {
    "free": {"name": "Бесплатный", "price_kopecks": 0},
    "pro": {"name": "Профессиональный", "price_kopecks": settings.pro_price_kopecks},
    "business": {"name": "Бизнес", "price_kopecks": settings.business_price_kopecks},
}


def plan_catalog() -> list[dict]:
    from app.services.usage import limits_for
    rows = []
    for key, item in PLANS.items():
        lim = limits_for(key)
        rows.append({
            "id": key,
            "name": item["name"],
            "price_kopecks": item["price_kopecks"],
            "period_days": settings.subscription_days if key != "free" else None,
            "limits": {"questions": lim.questions, "documents": lim.documents, "generations": lim.generations},
        })
    return rows


async def sync_subscription(db: AsyncSession, user: User) -> Subscription | None:
    sub = await db.scalar(select(Subscription).where(Subscription.user_id == user.id))
    now = datetime.now(timezone.utc)
    if sub and sub.status == "active" and sub.current_period_end and sub.current_period_end <= now:
        sub.status = "expired"
        sub.plan = "free"
        user.plan = "free"
        await db.flush()
    return sub


async def activate_plan(db: AsyncSession, user: User, payment: Payment) -> Subscription:
    now = datetime.now(timezone.utc)
    sub = await db.scalar(select(Subscription).where(Subscription.user_id == user.id))
    # YooKassa may deliver the same notification more than once. A payment grants
    # access exactly once; paid_at is our idempotency marker.
    if payment.paid_at is not None:
        if sub is None:
            sub = Subscription(user_id=user.id, plan=payment.plan, status="active", current_period_start=payment.paid_at, current_period_end=payment.paid_at + timedelta(days=settings.subscription_days), source_payment_id=payment.id)
            db.add(sub)
            user.plan = payment.plan
            await db.flush()
        return sub
    start = now
    if sub and sub.status == "active" and sub.current_period_end and sub.current_period_end > now and sub.plan == payment.plan:
        start = sub.current_period_end
    end = start + timedelta(days=settings.subscription_days)
    if sub is None:
        sub = Subscription(user_id=user.id, plan=payment.plan, status="active", current_period_start=now, current_period_end=end, source_payment_id=payment.id)
        db.add(sub)
    else:
        sub.plan = payment.plan
        sub.status = "active"
        sub.current_period_start = now
        sub.current_period_end = end
        sub.source_payment_id = payment.id
    user.plan = payment.plan
    payment.status = "succeeded"
    payment.paid_at = now
    await db.flush()
    return sub


async def create_checkout(db: AsyncSession, user: User, plan: str) -> Payment:
    if plan not in {"pro", "business"}:
        raise HTTPException(status_code=422, detail="Можно оплатить только тариф Pro или Business")
    amount_kopecks = int(PLANS[plan]["price_kopecks"])
    idem = str(uuid.uuid4())
    payment = Payment(user_id=user.id, provider=settings.billing_provider, idempotency_key=idem, plan=plan, amount_kopecks=amount_kopecks, status="pending")
    db.add(payment)
    await db.flush()

    if settings.billing_provider == "mock":
        payment.provider_payment_id = f"mock-{payment.id}"
        payment.confirmation_url = f"{settings.public_url}/?mock_payment={payment.id}"
        await activate_plan(db, user, payment)
        return payment

    if settings.billing_provider != "yookassa":
        raise HTTPException(status_code=503, detail="Онлайн-оплата пока не настроена владельцем сервиса")

    amount = f"{Decimal(amount_kopecks) / Decimal(100):.2f}"
    payload = {
        "amount": {"value": amount, "currency": "RUB"},
        "capture": True,
        "confirmation": {"type": "redirect", "return_url": settings.yookassa_return_url},
        "description": f"ПравоAI — тариф {plan.upper()} на {settings.subscription_days} дней",
        "save_payment_method": False,
        "metadata": {"user_id": str(user.id), "plan": plan, "internal_payment_id": str(payment.id)},
    }
    if settings.yookassa_receipt_enabled:
        payload["receipt"] = {
            "customer": {"email": user.email},
            "items": [{
                "description": f"Доступ к сервису ПравоAI, тариф {plan.upper()}, {settings.subscription_days} дней",
                "quantity": "1.00",
                "amount": {"value": amount, "currency": "RUB"},
                "vat_code": settings.yookassa_vat_code,
                "payment_mode": "full_payment",
                "payment_subject": "service",
            }],
            "internet": True,
        }
    async with httpx.AsyncClient(timeout=30.0) as client:
        response = await client.post(
            "https://api.yookassa.ru/v3/payments",
            auth=(settings.yookassa_shop_id, settings.yookassa_secret_key),
            headers={"Idempotence-Key": idem, "Content-Type": "application/json"},
            json=payload,
        )
        if response.status_code >= 400:
            payment.status = "failed"
            payment.provider_payload = {"status": response.status_code, "body": response.text[:2000]}
            raise HTTPException(status_code=502, detail="Платежный провайдер временно недоступен")
        data = response.json()
    payment.provider_payment_id = data.get("id")
    payment.status = data.get("status", "pending")
    payment.confirmation_url = (data.get("confirmation") or {}).get("confirmation_url")
    payment.provider_payload = data
    return payment


async def verify_yookassa_payment(payment_id: str) -> dict:
    if settings.billing_provider != "yookassa":
        raise HTTPException(status_code=503, detail="YooKassa не настроена")
    async with httpx.AsyncClient(timeout=30.0) as client:
        response = await client.get(
            f"https://api.yookassa.ru/v3/payments/{payment_id}",
            auth=(settings.yookassa_shop_id, settings.yookassa_secret_key),
        )
        response.raise_for_status()
        return response.json()
