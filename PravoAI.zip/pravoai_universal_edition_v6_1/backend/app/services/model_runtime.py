from __future__ import annotations

import json
from typing import Any

import httpx

from app.core.config import settings


def _ollama_native_base(base_url: str | None = None) -> str:
    base = (base_url or settings.ollama_base_url).rstrip("/")
    if base.endswith("/v1"):
        base = base[:-3]
    return base.rstrip("/")


async def call_ollama_chat(
    *,
    messages: list[dict[str, str]],
    model: str | None = None,
    json_mode: bool = False,
    think: bool | str = False,
    temperature: float = 0.25,
    timeout_seconds: int = 90,
    max_tokens: int = 2600,
) -> str:
    """Use Ollama's native chat API.

    Native /api/chat is intentional: it lets us control Qwen thinking mode on
    macOS/local deployments and avoids minutes of hidden reasoning for simple
    questions. The thinking text is never returned to the user.
    """
    payload: dict[str, Any] = {
        "model": model or settings.ollama_model,
        "messages": messages,
        "stream": False,
        "think": think,
        "options": {
            "temperature": temperature,
            "num_ctx": settings.local_context_tokens,
            "num_predict": max_tokens,
            "repeat_penalty": 1.05,
        },
    }
    if json_mode:
        payload["format"] = "json"
    async with httpx.AsyncClient(timeout=httpx.Timeout(timeout_seconds, connect=10)) as client:
        response = await client.post(f"{_ollama_native_base()}/api/chat", json=payload)
        response.raise_for_status()
        data = response.json()
        return str((data.get("message") or {}).get("content") or "").strip()


async def call_openai_chat(
    *,
    messages: list[dict[str, str]],
    model: str | None = None,
    json_mode: bool = False,
    temperature: float = 0.25,
    timeout_seconds: int = 100,
    max_tokens: int = 3000,
) -> str:
    headers = {"Content-Type": "application/json"}
    if settings.llm_api_key:
        headers["Authorization"] = f"Bearer {settings.llm_api_key}"
    payload: dict[str, Any] = {
        "model": model or settings.llm_model,
        "messages": messages,
        "temperature": temperature,
        "max_tokens": max_tokens,
    }
    if json_mode:
        payload["response_format"] = {"type": "json_object"}
    async with httpx.AsyncClient(timeout=httpx.Timeout(timeout_seconds, connect=10)) as client:
        response = await client.post(
            f"{settings.llm_base_url.rstrip('/')}/chat/completions",
            headers=headers,
            json=payload,
        )
        response.raise_for_status()
        return str(response.json()["choices"][0]["message"]["content"] or "").strip()


async def call_best_model(
    *,
    messages: list[dict[str, str]],
    json_mode: bool = False,
    think: bool | str = False,
    temperature: float = 0.25,
    timeout_seconds: int = 90,
    max_tokens: int = 3000,
) -> tuple[str, str]:
    """External reviewed model when configured; otherwise local Ollama."""
    if settings.llm_provider in {"auto", "openai_compatible"} and settings.llm_api_key:
        try:
            text = await call_openai_chat(
                messages=messages,
                json_mode=json_mode,
                temperature=temperature,
                timeout_seconds=timeout_seconds,
                max_tokens=max_tokens,
            )
            return text, settings.llm_model
        except Exception:
            if settings.llm_provider == "openai_compatible":
                raise
            # auto mode falls back to the private local model when the cloud
            # endpoint is temporarily unavailable.
    if settings.llm_provider in {"auto", "ollama"}:
        text = await call_ollama_chat(
            messages=messages,
            json_mode=json_mode,
            think=think,
            temperature=temperature,
            timeout_seconds=timeout_seconds,
            max_tokens=max_tokens,
        )
        return text, f"ollama:{settings.ollama_model}"
    raise RuntimeError("LLM provider is disabled")


def parse_json_object(text: str) -> dict[str, Any]:
    value = text.strip()
    if value.startswith("```"):
        value = value.split("\n", 1)[1] if "\n" in value else value
        value = value.rsplit("```", 1)[0]
    # Models occasionally prepend a short sentence even in JSON mode. Keep only
    # the outermost object instead of failing the whole answer.
    start = value.find("{")
    end = value.rfind("}")
    if start >= 0 and end > start:
        value = value[start : end + 1]
    return json.loads(value)
