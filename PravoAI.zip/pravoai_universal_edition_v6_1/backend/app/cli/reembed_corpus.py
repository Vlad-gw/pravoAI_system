from __future__ import annotations

import asyncio
from sqlalchemy import select
from redis.asyncio import Redis

from app.core.config import settings
from app.db.session import AsyncSessionLocal
from app.models.legal import LegalChunk
from app.services.embeddings import embed_text


async def main():
    signature = f"{settings.embedding_provider}:{settings.embedding_model}:{settings.ollama_embedding_model}:{settings.embedding_dim}"
    redis = Redis.from_url(settings.redis_url, decode_responses=True)
    try:
        if await redis.get("pravoai:embedding_signature") == signature:
            print(f"Embeddings already current: {signature}")
            return
        async with AsyncSessionLocal() as db:
            chunks = list((await db.scalars(select(LegalChunk).order_by(LegalChunk.id))).all())
            total = len(chunks)
            for i, chunk in enumerate(chunks, 1):
                chunk.embedding = await embed_text(chunk.text)
                if i % 25 == 0:
                    await db.commit()
                    print(f"Re-embedded {i}/{total}")
            await db.commit()
        await redis.set("pravoai:embedding_signature", signature)
        print(f"Embeddings updated: {total} chunks; {signature}")
    finally:
        await redis.aclose()


if __name__ == "__main__":
    asyncio.run(main())
