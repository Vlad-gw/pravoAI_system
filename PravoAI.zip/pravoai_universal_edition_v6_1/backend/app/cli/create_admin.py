from __future__ import annotations
import argparse
import asyncio
import os
from sqlalchemy import select
from app.core.security import hash_password, validate_password_strength
from app.db.session import AsyncSessionLocal
from app.models.app import User

async def run(email: str, password: str, name: str):
    async with AsyncSessionLocal() as db:
        existing = await db.scalar(select(User).where(User.email == email.lower()))
        if existing:
            existing.role = "admin"
            existing.is_active = True
            existing.password_hash = hash_password(password)
            existing.token_version += 1
            print(f"Updated admin: {email}")
        else:
            db.add(User(email=email.lower(), password_hash=hash_password(password), full_name=name, role="admin", plan="business"))
            print(f"Created admin: {email}")
        await db.commit()

async def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--email", required=True)
    parser.add_argument("--name", default="Администратор ПравоAI")
    args = parser.parse_args()
    password = os.getenv("PRAVOAI_ADMIN_PASSWORD", "")
    if len(password) < 10 or not any(c.isalpha() for c in password) or not any(c.isdigit() for c in password):
        raise SystemExit("Set PRAVOAI_ADMIN_PASSWORD (>=10 chars, letters+digits) in the command environment")
    await run(args.email, password, args.name)

if __name__ == "__main__":
    asyncio.run(main())
