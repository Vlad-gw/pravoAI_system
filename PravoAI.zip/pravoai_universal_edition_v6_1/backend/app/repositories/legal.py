from datetime import date
from uuid import UUID

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.domain.temporal import active_on_date
from app.models.legal import LegalDocument, LegalDocumentVersion


class LegalRepository:
    def __init__(self, session: AsyncSession):
        self.session = session

    async def list_documents(self, limit: int = 50, offset: int = 0) -> list[LegalDocument]:
        stmt = (
            select(LegalDocument)
            .order_by(LegalDocument.created_at.desc())
            .limit(limit)
            .offset(offset)
        )
        return list((await self.session.scalars(stmt)).all())

    async def get_active_version(
        self,
        document_id: UUID,
        target_date: date,
    ) -> LegalDocumentVersion | None:
        stmt = (
            select(LegalDocumentVersion)
            .where(
                LegalDocumentVersion.legal_document_id == document_id,
                active_on_date(
                    LegalDocumentVersion.effective_from,
                    LegalDocumentVersion.effective_to,
                    target_date,
                ),
            )
            .order_by(LegalDocumentVersion.effective_from.desc())
            .limit(1)
        )
        return await self.session.scalar(stmt)
