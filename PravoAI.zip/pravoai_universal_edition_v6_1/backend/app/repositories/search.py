from __future__ import annotations

from datetime import date

from sqlalchemy import Float, cast, func, or_, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.legal import LegalChunk, LegalDocument, LegalDocumentVersion


class SearchRepository:
    def __init__(self, session: AsyncSession):
        self.session = session

    async def lexical_search(self, query: str, target_date: date, limit: int = 10):
        ts_query = func.websearch_to_tsquery("russian", query)
        rank = cast(func.ts_rank_cd(LegalChunk.search_tsv, ts_query), Float).label("rank")
        stmt = (
            select(
                LegalChunk.id.label("chunk_id"),
                LegalDocument.id.label("document_id"),
                LegalDocumentVersion.id.label("version_id"),
                LegalDocument.title.label("document_title"),
                LegalDocument.number.label("document_number"),
                LegalChunk.article,
                LegalChunk.part,
                LegalDocumentVersion.effective_from,
                LegalDocumentVersion.effective_to,
                LegalChunk.text,
                rank,
                LegalDocument.source_url,
            )
            .join(LegalDocumentVersion, LegalChunk.version_id == LegalDocumentVersion.id)
            .join(LegalDocument, LegalDocumentVersion.legal_document_id == LegalDocument.id)
            .where(
                LegalChunk.search_tsv.op("@@")(ts_query),
                LegalDocumentVersion.effective_from <= target_date,
                or_(
                    LegalDocumentVersion.effective_to.is_(None),
                    LegalDocumentVersion.effective_to > target_date,
                ),
            )
            .order_by(rank.desc())
            .limit(limit)
        )
        return (await self.session.execute(stmt)).mappings().all()
