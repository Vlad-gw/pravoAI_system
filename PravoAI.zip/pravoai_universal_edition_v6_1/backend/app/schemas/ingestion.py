from __future__ import annotations

from datetime import date

from pydantic import BaseModel, Field, HttpUrl


class LegalMetadataBase(BaseModel):
    document_type: str = Field(min_length=1, max_length=100)
    title: str = Field(min_length=1)
    short_title: str | None = Field(default=None, max_length=255)
    number: str | None = Field(default=None, max_length=100)
    adoption_date: date | None = None
    external_id: str = Field(min_length=1, max_length=255)
    effective_from: date
    revision_date: date | None = None
    publication_date: date | None = None
    metadata: dict = Field(default_factory=dict)


class IngestFromUrlRequest(LegalMetadataBase):
    source_url: HttpUrl
    source_name: str = "Официальный интернет-портал правовой информации"


class IngestFromTextRequest(LegalMetadataBase):
    source_url: HttpUrl
    source_name: str = "Официальный интернет-портал правовой информации"
    raw_text: str = Field(min_length=20)


class IngestionResponse(BaseModel):
    document_id: str
    version_id: str
    created_document: bool
    created_version: bool
    chunks_count: int
