from __future__ import annotations

from datetime import datetime
from uuid import UUID

from pydantic import BaseModel, ConfigDict, EmailStr, Field


class RegisterRequest(BaseModel):
    email: EmailStr
    password: str = Field(min_length=10, max_length=128)
    full_name: str | None = Field(default=None, max_length=255)
    accept_terms: bool = False
    accept_privacy: bool = False


class LoginRequest(BaseModel):
    # Login intentionally accepts local/dev addresses (e.g. admin@pravoai.local).
    # Registration remains strict via EmailStr.
    email: str = Field(min_length=3, max_length=320)
    password: str = Field(min_length=1, max_length=128)


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    expires_in: int = 1200


class ConsentAcceptRequest(BaseModel):
    accept_terms: bool
    accept_privacy: bool


class ChangePasswordRequest(BaseModel):
    current_password: str = Field(min_length=1, max_length=128)
    new_password: str = Field(min_length=10, max_length=128)


class ProfileUpdateRequest(BaseModel):
    full_name: str | None = Field(default=None, max_length=255)
    region: str | None = Field(default=None, max_length=255)


class ForgotPasswordRequest(BaseModel):
    email: EmailStr


class ResetPasswordRequest(BaseModel):
    token: str = Field(min_length=20, max_length=256)
    new_password: str = Field(min_length=10, max_length=128)


class VerifyEmailRequest(BaseModel):
    token: str = Field(min_length=20, max_length=256)


class UserRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: UUID
    email: str
    full_name: str | None
    role: str
    plan: str
    region: str | None
    terms_version: str | None = None
    privacy_version: str | None = None
    email_verified_at: datetime | None = None
    requires_consent: bool = False
    requires_email_verification: bool = False
    created_at: datetime


class CaseCreate(BaseModel):
    title: str = Field(min_length=1, max_length=255)
    description: str | None = None


class CaseRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: UUID
    title: str
    description: str | None
    status: str
    created_at: datetime
    updated_at: datetime


class ConversationRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: UUID
    case_id: UUID | None
    title: str
    legal_area: str | None
    created_at: datetime
    updated_at: datetime


class ChatRequest(BaseModel):
    message: str = Field(min_length=2, max_length=12000)
    conversation_id: UUID | None = None
    case_id: UUID | None = None
    target_date: str | None = None
    region: str | None = None
    document_ids: list[UUID] = Field(default_factory=list, max_length=8)


class SourceRead(BaseModel):
    chunk_id: UUID
    document_title: str
    document_number: str | None
    article: str | None
    part: str | None
    effective_from: str
    effective_to: str | None
    source_url: str
    source_name: str
    reference_url: str | None = None
    reference_name: str | None = None
    official_url: str | None = None
    excerpt: str
    score: float
    is_snapshot: bool = False
    verified_as_of: str | None = None


class ChatResponse(BaseModel):
    conversation_id: UUID
    mode: str = "legal"
    message_id: UUID
    short_answer: str
    legal_basis: list[dict]
    application_to_case: str
    recommended_actions: list[str]
    possible_claims: list[str] = []
    evidence: list[str] = []
    deadlines: list[str]
    warnings: list[str]
    need_clarification: bool
    clarifying_questions: list[str]
    confidence: str
    legal_area: str
    target_date: str
    sources: list[SourceRead]
    provider: str


class MessageRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: UUID
    role: str
    content: str
    structured_json: dict
    confidence: str | None
    created_at: datetime


class DocumentRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: UUID
    case_id: UUID | None
    filename: str
    media_type: str | None
    size_bytes: int
    status: str
    created_at: datetime


class DocumentAskRequest(BaseModel):
    question: str = Field(min_length=2, max_length=6000)


class GenerateDocumentRequest(BaseModel):
    document_type: str
    case_id: UUID | None = None
    recipient: str | None = None
    applicant: str | None = None
    facts: str
    demand: str | None = None
    attachments: list[str] = []


class GeneratedDocumentRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: UUID
    document_type: str
    title: str
    content: str
    created_at: datetime


class FeedbackRequest(BaseModel):
    message_id: UUID
    useful: bool
    reason: str | None = None
    comment: str | None = None
