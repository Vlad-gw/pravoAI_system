from datetime import date
from uuid import UUID

from pydantic import BaseModel, ConfigDict


class LegalDocumentRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: UUID
    document_type: str
    title: str
    short_title: str | None
    number: str | None
    adoption_date: date | None
    source_name: str
    source_url: str


class LegalVersionRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: UUID
    legal_document_id: UUID
    revision_date: date | None
    publication_date: date | None
    effective_from: date
    effective_to: date | None
