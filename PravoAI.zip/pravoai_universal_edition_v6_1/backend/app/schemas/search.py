from datetime import date
from uuid import UUID

from pydantic import BaseModel


class LexicalSearchHit(BaseModel):
    chunk_id: UUID
    document_id: UUID
    version_id: UUID
    document_title: str
    document_number: str | None
    article: str | None
    part: str | None
    effective_from: date
    effective_to: date | None
    text: str
    rank: float
    source_url: str
