from __future__ import annotations

# Stable, public article pages used for the starter corpus.  The official
# document URL is still kept separately in LegalDocument.source_url.
ARTICLE_LINKS: dict[tuple[str, str], str] = {
    ("197-ФЗ", "80"): "https://www.consultant.ru/document/cons_doc_LAW_34683/aed7d03df679e3376974dadd131b899dc6966650/",
    ("197-ФЗ", "81"): "https://www.consultant.ru/document/cons_doc_LAW_34683/6a7ba42d8fda3a1ba186a9eb5c806921998ae7d1/",
    ("197-ФЗ", "84.1"): "https://www.consultant.ru/document/cons_doc_LAW_34683/cc8071b6b37792778d4ce9fba7e76c373edc0618/",
    ("197-ФЗ", "127"): "https://www.consultant.ru/document/cons_doc_LAW_34683/2f173da324a5464ef649b88f7347b8a17d200dae/",
    ("197-ФЗ", "136"): "https://www.consultant.ru/document/cons_doc_LAW_34683/a0a891ee650687026ef53d5d1194983419be6793/",
    ("197-ФЗ", "140"): "https://www.consultant.ru/document/cons_doc_LAW_34683/274f022222909efcef192f7615b143e34309164f/",
    ("197-ФЗ", "142"): "https://www.consultant.ru/document/cons_doc_LAW_34683/67f5b7767847d2483a67262f342f35cf922855a2/",
    ("197-ФЗ", "178"): "https://www.consultant.ru/document/cons_doc_LAW_34683/0526867a7eace3f1f88798592ed0bdf3589f0528/",
    ("197-ФЗ", "179"): "https://www.consultant.ru/document/cons_doc_LAW_34683/ddaeeb833c24609e3474ce13536b0796bc85ee57/",
    ("197-ФЗ", "180"): "https://www.consultant.ru/document/cons_doc_LAW_34683/6887e2fd9f9775c467fb9cc45fbc5874a04174cc/",
    ("197-ФЗ", "236"): "https://www.consultant.ru/document/cons_doc_LAW_34683/7c8d2fe49f0c8b8d13723803f2e82228f99b6d7e/",
    ("197-ФЗ", "261"): "https://www.consultant.ru/document/cons_doc_LAW_34683/ede188a86ee930ba7b9e1163bc567d7897a43921/",
    ("197-ФЗ", "352"): "https://www.consultant.ru/document/cons_doc_LAW_34683/4b07ec615bc5f7ca99a620c9e9767f845ea9a463/",
    ("197-ФЗ", "356"): "https://www.consultant.ru/document/cons_doc_LAW_34683/e1d3302610bfe8a8ec24f33c3029360eeab27635/",
    ("197-ФЗ", "392"): "https://www.consultant.ru/document/cons_doc_LAW_34683/eff4cd3e27ee6ffdc716306e3cab5c403c3c2dcb/",
    ("197-ФЗ", "393"): "https://www.consultant.ru/document/cons_doc_LAW_34683/fa078656e3d953e68ce80648f7419945fb1e27ba/",
    ("197-ФЗ", "394"): "https://www.consultant.ru/document/cons_doc_LAW_34683/866dec528c62e132ee3463fa0814d217434849b0/",
    ("2300-1", "18"): "https://www.consultant.ru/document/cons_doc_LAW_305/76ae101b731ecc22467fd9f1f14cb9e2b8799026/",
    ("2300-1", "21"): "https://www.consultant.ru/document/cons_doc_LAW_305/6dd6c070a38a1de71282c1f0206c1d9131d7446c/",
    ("2300-1", "22"): "https://www.consultant.ru/document/cons_doc_LAW_305/00616d1e160d7ff7ac8d5a6a8e4525fb75e3b486/",
    ("2300-1", "23.1"): "https://www.consultant.ru/document/cons_doc_LAW_305/cd5055f2729d0ba6bf1c3724ba16ca46ea92e0f7/",
    ("2300-1", "25"): "https://www.consultant.ru/document/cons_doc_LAW_305/07e266c138f7d30d498ff235626083e75b770ff3/",
    ("2300-1", "26.1"): "https://www.consultant.ru/document/cons_doc_LAW_305/1525b1a2f037db240c8e6a749619f86e53857f13/",
    ("2300-1", "15"): "https://www.consultant.ru/document/cons_doc_LAW_305/19c8339aa764510f25f4afcea83230cbf14cb9d3/",
    ("2300-1", "17"): "https://www.consultant.ru/document/cons_doc_LAW_305/e38dd0dc96d081c4325d34a3d2a1cd3d037e7fec/",
    ("14-ФЗ", "467"): "https://www.consultant.ru/document/cons_doc_LAW_9027/46945e05c7c59652c82da91f2119abe4d9b58e68/",
    ("14-ФЗ", "468"): "https://www.consultant.ru/document/cons_doc_LAW_9027/e9129374a53943e07d6e398c389820e813059c96/",
}

DOC_LINKS = {
    "197-ФЗ": "https://www.consultant.ru/document/cons_doc_LAW_34683/",
    "2300-1": "https://www.consultant.ru/document/cons_doc_LAW_305/",
    "14-ФЗ": "https://www.consultant.ru/document/cons_doc_LAW_9027/",
}


def reference_url(document_number: str | None, article: str | None) -> str | None:
    if not document_number:
        return None
    if article:
        found = ARTICLE_LINKS.get((document_number, article))
        if found:
            return found
    return DOC_LINKS.get(document_number)
