from datetime import date

from sqlalchemy import and_, or_
from sqlalchemy.sql.elements import ColumnElement


def revision_is_active(
    *,
    effective_from: date,
    effective_to: date | None,
    target_date: date,
) -> bool:
    """Pure helper used by tests and non-SQL workflows."""
    return effective_from <= target_date and (
        effective_to is None or effective_to > target_date
    )


def active_on_date(
    effective_from_column,
    effective_to_column,
    target_date: date,
) -> ColumnElement[bool]:
    """
    SQL predicate matching the TZ requirements:
      effective_from <= target_date
      AND (effective_to > target_date OR effective_to IS NULL)
    """
    return and_(
        effective_from_column <= target_date,
        or_(
            effective_to_column.is_(None),
            effective_to_column > target_date,
        ),
    )
