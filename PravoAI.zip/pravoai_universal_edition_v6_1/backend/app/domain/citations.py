from dataclasses import dataclass
from uuid import UUID


@dataclass(frozen=True, slots=True)
class CitationCheck:
    valid: bool
    invalid_source_ids: tuple[UUID, ...]


def validate_citation_source_ids(
    cited_source_ids: list[UUID],
    retrieved_source_ids: set[UUID],
) -> CitationCheck:
    """
    A generated answer may cite only chunks that were actually retrieved.
    More checks (article/document/revision/date) will be added at the LLM layer.
    """
    invalid = tuple(
        source_id
        for source_id in cited_source_ids
        if source_id not in retrieved_source_ids
    )
    return CitationCheck(valid=not invalid, invalid_source_ids=invalid)
