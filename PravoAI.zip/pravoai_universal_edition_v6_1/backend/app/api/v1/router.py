from fastapi import APIRouter

from app.api.v1.endpoints import admin, auth, billing, cases, chat, documents, feedback, generation, health, ingestion, legal, public, search

api_router = APIRouter()
api_router.include_router(health.router, tags=["health"])
api_router.include_router(public.router, prefix="/public", tags=["public"])
api_router.include_router(billing.router, prefix="/billing", tags=["billing"])
api_router.include_router(auth.router, prefix="/auth", tags=["auth"])
api_router.include_router(chat.router, prefix="/chat", tags=["chat"])
api_router.include_router(cases.router, prefix="/cases", tags=["cases"])
api_router.include_router(documents.router, prefix="/documents", tags=["documents"])
api_router.include_router(generation.router, prefix="/generated-documents", tags=["generated-documents"])
api_router.include_router(feedback.router, prefix="/feedback", tags=["feedback"])
api_router.include_router(legal.router, prefix="/legal", tags=["legal"])
api_router.include_router(search.router, prefix="/legal/search", tags=["search"])
api_router.include_router(ingestion.router, prefix="/admin/ingestion", tags=["admin-ingestion"])
api_router.include_router(admin.router, prefix="/admin", tags=["admin"])
