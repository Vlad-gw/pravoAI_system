import uuid

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.security import get_current_user, require_product_access
from app.db.session import get_db
from app.models.app import Case, User
from app.schemas.product import CaseCreate, CaseRead

router = APIRouter()


@router.get("", response_model=list[CaseRead])
async def list_cases(user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)):
    return list((await db.scalars(select(Case).where(Case.user_id == user.id).order_by(Case.updated_at.desc()))).all())


@router.post("", response_model=CaseRead, status_code=201)
async def create_case(payload: CaseCreate, user: User = Depends(require_product_access), db: AsyncSession = Depends(get_db)):
    item = Case(user_id=user.id, title=payload.title, description=payload.description)
    db.add(item)
    await db.commit(); await db.refresh(item)
    return item


@router.delete("/{case_id}", status_code=204)
async def delete_case(case_id: uuid.UUID, user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)):
    item = await db.scalar(select(Case).where(Case.id == case_id, Case.user_id == user.id))
    if item is None: raise HTTPException(404, "Дело не найдено")
    await db.delete(item); await db.commit()
