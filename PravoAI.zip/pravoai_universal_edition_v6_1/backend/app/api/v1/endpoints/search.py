from datetime import date

from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.session import get_db
from app.repositories.search import SearchRepository
from app.schemas.search import LexicalSearchHit

router = APIRouter()


@router.get("", response_model=list[LexicalSearchHit])
async def search_legal_chunks(
    q: str = Query(min_length=2, max_length=500),
    target_date: date = Query(...),
    limit: int = Query(default=10, ge=1, le=50),
    db: AsyncSession = Depends(get_db),
):
    rows = await SearchRepository(db).lexical_search(q, target_date, limit)
    return [LexicalSearchHit(**row) for row in rows]
