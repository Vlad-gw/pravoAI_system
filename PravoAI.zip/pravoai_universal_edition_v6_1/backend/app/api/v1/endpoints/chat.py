import uuid

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.core.security import get_current_user, require_product_access
from app.db.session import get_db
from app.models.app import AnswerSource, Conversation, Message, UploadedDocument, User
from app.schemas.product import ChatRequest, ChatResponse, ConversationRead, MessageRead, SourceRead
from app.services.chat import PROMPT_VERSION
from app.services.assistant import answer_assistant_question
from app.data.legal_links import reference_url
from app.services.files import relevant_passages
from app.services.usage import enforce_quota

router = APIRouter()


@router.get("/conversations", response_model=list[ConversationRead])
async def conversations(user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)):
    return list((await db.scalars(select(Conversation).where(Conversation.user_id == user.id).order_by(Conversation.updated_at.desc()))).all())


@router.get("/conversations/{conversation_id}", response_model=list[MessageRead])
async def conversation_messages(conversation_id: uuid.UUID, user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)):
    convo = await db.scalar(select(Conversation).where(Conversation.id == conversation_id, Conversation.user_id == user.id))
    if convo is None: raise HTTPException(404, "Диалог не найден")
    return list((await db.scalars(select(Message).where(Message.conversation_id == convo.id).order_by(Message.created_at))).all())


@router.delete("/conversations/{conversation_id}", status_code=204)
async def delete_conversation(conversation_id: uuid.UUID, user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)):
    convo = await db.scalar(select(Conversation).where(Conversation.id == conversation_id, Conversation.user_id == user.id))
    if convo is None: raise HTTPException(404, "Диалог не найден")
    await db.delete(convo); await db.commit()


@router.post("/messages", response_model=ChatResponse)
async def send_message(payload: ChatRequest, user: User = Depends(require_product_access), db: AsyncSession = Depends(get_db)):
    await enforce_quota(db, user, "questions")
    convo = None
    if payload.conversation_id:
        convo = await db.scalar(select(Conversation).where(Conversation.id == payload.conversation_id, Conversation.user_id == user.id))
        if convo is None: raise HTTPException(404, "Диалог не найден")
    if convo is None:
        convo = Conversation(user_id=user.id, case_id=payload.case_id, title=payload.message[:80])
        db.add(convo); await db.flush()

    # Keep conversational memory. Assistant text is context only; in legal mode
    # it is never treated as a source of law.
    history_rows = list((await db.scalars(
        select(Message)
        .where(Message.conversation_id == convo.id)
        .order_by(Message.created_at.desc())
        .limit(12)
    )).all())
    history_rows.reverse()
    conversation_history = []
    for m in history_rows:
        content = m.content
        # Older messages stored only the short answer in `content`; recover the
        # visible follow-up questions/actions from structured_json so phrases
        # like «я ответил» or «уже оформлено» keep their real conversational context.
        if m.role == "assistant" and isinstance(m.structured_json, dict) and m.structured_json:
            d = m.structured_json
            parts = [str(d.get("short_answer") or ""), str(d.get("application_to_case") or "")]
            qs = [str(x) for x in (d.get("clarifying_questions") or []) if x]
            actions = [str(x) for x in (d.get("recommended_actions") or []) if x]
            if qs:
                parts.append("Уточняющие вопросы: " + " | ".join(qs))
            if actions:
                parts.append("Рекомендованные действия: " + " | ".join(actions[:4]))
            content = "\n".join(x for x in parts if x).strip() or content
        conversation_history.append({"role": m.role, "content": content})
    previous_user_messages = [m.content for m in history_rows if m.role == "user"][-4:]

    user_message = Message(conversation_id=convo.id, role="user", content=payload.message, structured_json={})
    db.add(user_message); await db.flush()

    factual_context = None
    docs = []
    if payload.document_ids:
        docs = list((await db.scalars(
            select(UploadedDocument).where(
                UploadedDocument.user_id == user.id,
                UploadedDocument.id.in_(payload.document_ids),
            )
        )).all())
        if len(docs) != len(set(payload.document_ids)):
            raise HTTPException(404, "Один из прикрепленных документов не найден")
        for doc in docs:
            doc.conversation_id = convo.id
    else:
        # Follow-up questions in the same chat automatically keep the attached documents in context.
        docs = list((await db.scalars(
            select(UploadedDocument).where(
                UploadedDocument.user_id == user.id,
                UploadedDocument.conversation_id == convo.id,
            ).order_by(UploadedDocument.created_at.desc()).limit(8)
        )).all())
    if docs:
        context_parts = []
        for doc in docs:
            passages = relevant_passages(doc.text_content, payload.message)[:5]
            if passages:
                context_parts.append(f"ДОКУМЕНТ: {doc.filename}\n" + "\n\n".join(passages))
        factual_context = "\n\n---\n\n".join(context_parts)[:14000] or None

    result = await answer_assistant_question(
        db,
        question=payload.message,
        target_date_text=payload.target_date,
        region=payload.region or user.region,
        previous_user_messages=previous_user_messages,
        conversation_history=conversation_history,
        prior_area=convo.legal_area,
        factual_context=factual_context,
        has_documents=bool(docs),
    )
    data = result.data
    convo.legal_area = data["legal_area"]
    # Persist enough of the visible answer for future conversational turns.
    assistant_parts = [data.get("short_answer", ""), data.get("application_to_case", "")]
    if data.get("clarifying_questions"):
        assistant_parts.append("Уточняющие вопросы: " + " | ".join(data["clarifying_questions"]))
    assistant_text = "\n\n".join(x for x in assistant_parts if x)
    assistant_message = Message(
        conversation_id=convo.id, role="assistant", content=assistant_text,
        structured_json=data, target_date=data["target_date"], confidence=data["confidence"],
        model_name=result.provider, prompt_version=PROMPT_VERSION, latency_ms=result.latency_ms,
    )
    db.add(assistant_message); await db.flush()
    for rank, hit in enumerate(result.hits, 1):
        db.add(AnswerSource(message_id=assistant_message.id, legal_chunk_id=hit.chunk_id, rank=rank, score=int(hit.score * 1_000_000)))
    await db.commit(); await db.refresh(assistant_message)

    sources = [SourceRead(
        chunk_id=h.chunk_id, document_title=h.document_title, document_number=h.document_number,
        article=h.article, part=h.part, effective_from=h.effective_from.isoformat(),
        effective_to=h.effective_to.isoformat() if h.effective_to else None,
        source_url=h.source_url, source_name=h.source_name,
        reference_url=reference_url(h.document_number, h.article),
        reference_name="КонсультантПлюс — текст статьи" if reference_url(h.document_number, h.article) else None,
        official_url=h.source_url, excerpt=h.text[:1200], score=float(h.score),
        is_snapshot=h.is_snapshot, verified_as_of=h.verified_as_of,
    ) for h in result.hits]
    return ChatResponse(conversation_id=convo.id, message_id=assistant_message.id, sources=sources, provider=result.provider, **data)
