from fastapi import APIRouter, HTTPException
from redis.asyncio import Redis
from sqlalchemy import func, select, text

from app.core.config import settings
from app.db.session import AsyncSessionLocal, engine
from app.models.legal import LegalDocument, LegalDocumentVersion

router = APIRouter()


@router.get("/health")
async def health() -> dict[str, str]:
    return {"status": "ok", "service": "pravoai-api", "version": settings.app_version}


@router.get("/ready")
async def ready():
    checks: dict[str, object] = {"database": False, "redis": False, "legal_corpus": False}
    try:
        async with engine.connect() as conn:
            await conn.execute(text("SELECT 1"))
        checks["database"] = True
    except Exception:
        pass

    try:
        client = Redis.from_url(settings.redis_url)
        await client.ping()
        await client.aclose()
        checks["redis"] = True
    except Exception:
        pass

    try:
        async with AsyncSessionLocal() as db:
            docs = int((await db.scalar(select(func.count()).select_from(LegalDocument))) or 0)
            snapshots = int((await db.scalar(
                select(func.count()).select_from(LegalDocumentVersion).where(
                    LegalDocumentVersion.metadata_json["starter_snapshot"].astext == "true"
                )
            )) or 0)
            checks["legal_documents"] = docs
            checks["starter_snapshot_versions"] = snapshots
            checks["legal_corpus"] = docs > 0 and (not settings.is_production or snapshots == 0)
    except Exception:
        pass

    essential = bool(checks["database"] and checks["redis"] and checks["legal_corpus"])
    if not essential:
        raise HTTPException(status_code=503, detail={"status": "not_ready", "checks": checks})
    return {"status": "ready", "checks": checks}
