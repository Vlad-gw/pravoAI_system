from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.security import get_current_user
from app.db.session import get_db
from app.models.app import Feedback, User
from app.schemas.product import FeedbackRequest

router = APIRouter()


@router.post("", status_code=201)
async def create_feedback(payload: FeedbackRequest, user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)):
    item = Feedback(user_id=user.id, message_id=payload.message_id, useful=payload.useful, reason=payload.reason, comment=payload.comment)
    db.add(item); await db.commit()
    return {"status": "ok"}
