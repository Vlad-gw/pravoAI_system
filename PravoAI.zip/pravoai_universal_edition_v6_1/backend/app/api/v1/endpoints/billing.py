from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.core.security import get_current_user, require_product_access
from app.db.session import get_db
from app.models.app import Payment, Subscription, User
from app.services.audit import audit
from app.services.billing import activate_plan, create_checkout, plan_catalog, sync_subscription, verify_yookassa_payment
from app.services.usage import usage_for

router = APIRouter()


class CheckoutRequest(BaseModel):
    plan: str


@router.get("/plans")
async def plans():
    return {"billing_enabled": settings.billing_provider in {"mock", "yookassa"}, "provider": settings.billing_provider, "plans": plan_catalog()}


@router.get("/me")
async def billing_me(user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)):
    sub = await sync_subscription(db, user)
    await db.commit()
    return {
        "plan": user.plan,
        "subscription": None if not sub else {
            "status": sub.status,
            "plan": sub.plan,
            "current_period_end": sub.current_period_end.isoformat() if sub.current_period_end else None,
        },
        "usage": await usage_for(db, user),
    }


@router.post("/checkout")
async def checkout(payload: CheckoutRequest, request: Request, user: User = Depends(require_product_access), db: AsyncSession = Depends(get_db)):
    payment = await create_checkout(db, user, payload.plan)
    await audit(db, request, "billing.checkout_created", user=user, target_type="payment", target_id=str(payment.id), metadata={"plan": payload.plan})
    await db.commit()
    return {"payment_id": str(payment.id), "status": payment.status, "confirmation_url": payment.confirmation_url, "plan": payment.plan}


@router.post("/webhook/yookassa")
async def yookassa_webhook(request: Request, db: AsyncSession = Depends(get_db)):
    # Webhook payload is not trusted. We re-fetch the payment from YooKassa API before granting access.
    payload = await request.json()
    obj = payload.get("object") or {}
    provider_id = obj.get("id")
    if not provider_id:
        raise HTTPException(status_code=400, detail="payment id missing")
    payment = await db.scalar(select(Payment).where(Payment.provider_payment_id == provider_id))
    if payment is None:
        return {"ok": True}
    verified = await verify_yookassa_payment(provider_id)
    payment.provider_payload = verified
    payment.status = verified.get("status", payment.status)
    if verified.get("status") == "succeeded":
        user = await db.get(User, payment.user_id)
        if user:
            await activate_plan(db, user, payment)
            await audit(db, request, "billing.payment_succeeded", user=user, target_type="payment", target_id=str(payment.id), metadata={"plan": payment.plan})
    await db.commit()
    return {"ok": True}
