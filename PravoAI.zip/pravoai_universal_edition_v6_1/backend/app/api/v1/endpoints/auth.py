from __future__ import annotations

from datetime import datetime, timedelta, timezone
import hashlib
import os

from fastapi import APIRouter, Depends, HTTPException, Request, Response
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.core.security import (
    clear_refresh_cookie,
    create_access_token,
    create_refresh_session,
    get_current_user,
    hash_password,
    revoke_all_user_sessions,
    revoke_refresh_session,
    rotate_refresh_session,
    set_refresh_cookie,
    validate_password_strength,
    verify_password,
)
from app.db.session import get_db
from app.models.app import Case, ConsentRecord, Conversation, GeneratedDocument, Message, Payment, UploadedDocument, User
from app.schemas.product import (
    ChangePasswordRequest,
    ConsentAcceptRequest,
    ForgotPasswordRequest,
    LoginRequest,
    ProfileUpdateRequest,
    RegisterRequest,
    ResetPasswordRequest,
    TokenResponse,
    UserRead,
    VerifyEmailRequest,
)
from app.services.audit import audit, ip_hash
from app.services.email import EmailDeliveryError, reset_message, send_email, verification_message
from app.services.email_tokens import consume_email_token, create_email_token

router = APIRouter()


def _user_read(user: User) -> UserRead:
    item = UserRead.model_validate(user)
    return item.model_copy(update={
        "requires_consent": bool(settings.require_terms_acceptance and (
            user.terms_version != settings.terms_version or user.privacy_version != settings.privacy_version
        )),
        "requires_email_verification": bool(
            settings.require_email_verification and user.role != "admin" and user.email_verified_at is None
        ),
    })


async def _issue_session(user: User, request: Request, response: Response, db: AsyncSession) -> TokenResponse:
    raw_refresh = await create_refresh_session(db, user, request)
    set_refresh_cookie(response, raw_refresh)
    return TokenResponse(access_token=create_access_token(user), expires_in=settings.access_token_minutes * 60)


@router.post("/register", response_model=TokenResponse, status_code=201)
async def register(payload: RegisterRequest, request: Request, response: Response, db: AsyncSession = Depends(get_db)):
    validate_password_strength(payload.password)
    if settings.require_terms_acceptance and (not payload.accept_terms or not payload.accept_privacy):
        raise HTTPException(status_code=422, detail="Для регистрации необходимо принять условия использования и политику обработки персональных данных")
    email = payload.email.lower()
    if await db.scalar(select(User.id).where(User.email == email)):
        raise HTTPException(status_code=409, detail="Пользователь с таким email уже существует")
    now = datetime.now(timezone.utc)
    user = User(
        email=email,
        password_hash=hash_password(payload.password),
        full_name=payload.full_name,
        role="user",
        plan="free",
        terms_version=settings.terms_version if payload.accept_terms else None,
        privacy_version=settings.privacy_version if payload.accept_privacy else None,
        consented_at=now if payload.accept_terms and payload.accept_privacy else None,
        email_verified_at=None if settings.require_email_verification else now,
    )
    db.add(user)
    await db.flush()
    if payload.accept_terms:
        db.add(ConsentRecord(user_id=user.id, consent_type="terms", version=settings.terms_version, ip_hash=ip_hash(request)))
    if payload.accept_privacy:
        db.add(ConsentRecord(user_id=user.id, consent_type="personal_data", version=settings.privacy_version, ip_hash=ip_hash(request)))
    verify_raw: str | None = None
    if settings.require_email_verification:
        verify_raw = await create_email_token(db, user.id, "verify_email", timedelta(hours=settings.verification_token_hours))
    await audit(db, request, "auth.register", user=user)
    token = await _issue_session(user, request, response, db)
    await db.commit()

    if verify_raw and settings.email_provider == "smtp":
        subject, text, body = verification_message(verify_raw)
        try:
            await send_email(user.email, subject, text, body)
        except EmailDeliveryError:
            # Account remains valid but gated; user can use resend after SMTP recovers.
            pass
    return token


@router.post("/login", response_model=TokenResponse)
async def login(payload: LoginRequest, request: Request, response: Response, db: AsyncSession = Depends(get_db)):
    user = await db.scalar(select(User).where(User.email == payload.email.lower(), User.deleted_at.is_(None)))
    if user is None or not verify_password(payload.password, user.password_hash) or not user.is_active:
        await audit(db, request, "auth.login_failed", metadata={"email_hash": hashlib.sha256(payload.email.lower().encode()).hexdigest()})
        await db.commit()
        raise HTTPException(status_code=401, detail="Неверный email или пароль")
    user.last_login_at = datetime.now(timezone.utc)
    await audit(db, request, "auth.login", user=user)
    token = await _issue_session(user, request, response, db)
    await db.commit()
    return token


@router.post("/token", response_model=TokenResponse, include_in_schema=True)
async def token_login(request: Request, response: Response, form: OAuth2PasswordRequestForm = Depends(), db: AsyncSession = Depends(get_db)):
    user = await db.scalar(select(User).where(User.email == form.username.lower(), User.deleted_at.is_(None)))
    if user is None or not verify_password(form.password, user.password_hash) or not user.is_active:
        raise HTTPException(status_code=401, detail="Неверный email или пароль")
    user.last_login_at = datetime.now(timezone.utc)
    token = await _issue_session(user, request, response, db)
    await db.commit()
    return token


@router.post("/refresh", response_model=TokenResponse)
async def refresh(request: Request, response: Response, db: AsyncSession = Depends(get_db)):
    raw = request.cookies.get(settings.refresh_cookie_name)
    if not raw:
        raise HTTPException(status_code=401, detail="Refresh-сессия отсутствует")
    user, new_raw = await rotate_refresh_session(db, raw, request)
    set_refresh_cookie(response, new_raw)
    await audit(db, request, "auth.refresh", user=user)
    await db.commit()
    return TokenResponse(access_token=create_access_token(user), expires_in=settings.access_token_minutes * 60)


@router.post("/logout", status_code=204)
async def logout(request: Request, response: Response, db: AsyncSession = Depends(get_db)):
    raw = request.cookies.get(settings.refresh_cookie_name)
    await revoke_refresh_session(db, raw)
    clear_refresh_cookie(response)
    await db.commit()


@router.get("/me", response_model=UserRead)
async def me(user: User = Depends(get_current_user)):
    return _user_read(user)


@router.post("/consent", response_model=UserRead)
async def accept_consent(payload: ConsentAcceptRequest, request: Request, user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)):
    if not payload.accept_terms or not payload.accept_privacy:
        raise HTTPException(status_code=422, detail="Необходимо принять актуальные условия и политику")
    now = datetime.now(timezone.utc)
    user.terms_version = settings.terms_version
    user.privacy_version = settings.privacy_version
    user.consented_at = now
    db.add(ConsentRecord(user_id=user.id, consent_type="terms", version=settings.terms_version, ip_hash=ip_hash(request)))
    db.add(ConsentRecord(user_id=user.id, consent_type="personal_data", version=settings.privacy_version, ip_hash=ip_hash(request)))
    await audit(db, request, "auth.consent_updated", user=user, metadata={"terms": settings.terms_version, "privacy": settings.privacy_version})
    await db.commit()
    return _user_read(user)


@router.post("/resend-verification")
async def resend_verification(request: Request, user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)):
    if not settings.require_email_verification or user.email_verified_at is not None or user.role == "admin":
        return {"ok": True}
    if settings.email_provider != "smtp":
        raise HTTPException(status_code=503, detail="Отправка email пока не настроена владельцем сервиса")
    raw = await create_email_token(db, user.id, "verify_email", timedelta(hours=settings.verification_token_hours))
    await audit(db, request, "auth.verification_resent", user=user)
    await db.commit()
    subject, text, body = verification_message(raw)
    try:
        await send_email(user.email, subject, text, body)
    except Exception:
        raise HTTPException(status_code=503, detail="Не удалось отправить письмо. Попробуйте позже")
    return {"ok": True}


@router.post("/verify-email", response_model=UserRead)
async def verify_email(payload: VerifyEmailRequest, request: Request, db: AsyncSession = Depends(get_db)):
    row = await consume_email_token(db, payload.token, "verify_email")
    if row is None:
        raise HTTPException(status_code=400, detail="Ссылка подтверждения недействительна или истекла")
    user = await db.scalar(select(User).where(User.id == row.user_id, User.deleted_at.is_(None)))
    if user is None:
        raise HTTPException(status_code=400, detail="Аккаунт не найден")
    user.email_verified_at = datetime.now(timezone.utc)
    await audit(db, request, "auth.email_verified", user=user)
    await db.commit()
    return _user_read(user)


@router.post("/forgot-password")
async def forgot_password(payload: ForgotPasswordRequest, request: Request, db: AsyncSession = Depends(get_db)):
    # Always return the same response to prevent account enumeration.
    user = await db.scalar(select(User).where(User.email == payload.email.lower(), User.deleted_at.is_(None), User.is_active.is_(True)))
    if user and settings.email_provider == "smtp":
        raw = await create_email_token(db, user.id, "password_reset", timedelta(minutes=settings.password_reset_token_minutes))
        await audit(db, request, "auth.password_reset_requested", user=user)
        await db.commit()
        subject, text, body = reset_message(raw)
        try:
            await send_email(user.email, subject, text, body)
        except Exception:
            pass
    else:
        await db.commit()
    return {"ok": True, "message": "Если аккаунт существует, инструкции отправлены на email"}


@router.post("/reset-password", status_code=204)
async def reset_password(payload: ResetPasswordRequest, request: Request, response: Response, db: AsyncSession = Depends(get_db)):
    validate_password_strength(payload.new_password)
    row = await consume_email_token(db, payload.token, "password_reset")
    if row is None:
        raise HTTPException(status_code=400, detail="Ссылка сброса пароля недействительна или истекла")
    user = await db.scalar(select(User).where(User.id == row.user_id, User.deleted_at.is_(None), User.is_active.is_(True)))
    if user is None:
        raise HTTPException(status_code=400, detail="Аккаунт не найден")
    user.password_hash = hash_password(payload.new_password)
    await revoke_all_user_sessions(db, user)
    clear_refresh_cookie(response)
    await audit(db, request, "auth.password_reset_completed", user=user)
    await db.commit()


@router.patch("/profile", response_model=UserRead)
async def update_profile(payload: ProfileUpdateRequest, request: Request, user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)):
    user.full_name = payload.full_name.strip() if payload.full_name and payload.full_name.strip() else None
    user.region = payload.region.strip() if payload.region and payload.region.strip() else None
    await audit(db, request, "account.profile_updated", user=user)
    await db.commit()
    return _user_read(user)


@router.post("/change-password", status_code=204)
async def change_password(payload: ChangePasswordRequest, request: Request, response: Response, user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)):
    if not verify_password(payload.current_password, user.password_hash):
        raise HTTPException(status_code=400, detail="Текущий пароль указан неверно")
    validate_password_strength(payload.new_password)
    user.password_hash = hash_password(payload.new_password)
    await revoke_all_user_sessions(db, user)
    clear_refresh_cookie(response)
    await audit(db, request, "auth.password_changed", user=user)
    await db.commit()


@router.get("/account/export")
async def export_account(user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)):
    cases = list((await db.scalars(select(Case).where(Case.user_id == user.id))).all())
    conversations = list((await db.scalars(select(Conversation).where(Conversation.user_id == user.id))).all())
    convo_ids = [x.id for x in conversations]
    messages = list((await db.scalars(select(Message).where(Message.conversation_id.in_(convo_ids)).order_by(Message.created_at))).all()) if convo_ids else []
    documents = list((await db.scalars(select(UploadedDocument).where(UploadedDocument.user_id == user.id))).all())
    generated = list((await db.scalars(select(GeneratedDocument).where(GeneratedDocument.user_id == user.id))).all())
    consents = list((await db.scalars(select(ConsentRecord).where(ConsentRecord.user_id == user.id))).all())
    payments = list((await db.scalars(select(Payment).where(Payment.user_id == user.id))).all())
    return {
        "exported_at": datetime.now(timezone.utc).isoformat(),
        "user": {"id": str(user.id), "email": user.email, "full_name": user.full_name, "region": user.region, "plan": user.plan, "created_at": user.created_at.isoformat()},
        "cases": [{"id": str(x.id), "title": x.title, "description": x.description, "status": x.status, "created_at": x.created_at.isoformat()} for x in cases],
        "conversations": [{"id": str(x.id), "title": x.title, "legal_area": x.legal_area, "case_id": str(x.case_id) if x.case_id else None, "created_at": x.created_at.isoformat()} for x in conversations],
        "messages": [{"id": str(x.id), "conversation_id": str(x.conversation_id), "role": x.role, "content": x.content, "target_date": x.target_date, "confidence": x.confidence, "created_at": x.created_at.isoformat()} for x in messages],
        "documents": [{"id": str(x.id), "filename": x.filename, "size_bytes": x.size_bytes, "status": x.status, "created_at": x.created_at.isoformat()} for x in documents],
        "generated_documents": [{"id": str(x.id), "title": x.title, "type": x.document_type, "content": x.content, "created_at": x.created_at.isoformat()} for x in generated],
        "consents": [{"type": x.consent_type, "version": x.version, "accepted_at": x.accepted_at.isoformat()} for x in consents],
        "payments": [{"id": str(x.id), "provider": x.provider, "plan": x.plan, "amount_kopecks": x.amount_kopecks, "currency": x.currency, "status": x.status, "created_at": x.created_at.isoformat()} for x in payments],
    }


@router.delete("/account", status_code=204)
async def delete_account(request: Request, response: Response, user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)):
    docs = list((await db.scalars(select(UploadedDocument).where(UploadedDocument.user_id == user.id))).all())
    paths = [x.storage_path for x in docs]
    await audit(db, request, "account.delete", user=user)
    await db.delete(user)
    await db.commit()
    for path in paths:
        try:
            os.remove(path)
        except FileNotFoundError:
            pass
    clear_refresh_cookie(response)
