from datetime import date
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.session import get_db
from app.repositories.legal import LegalRepository
from app.schemas.legal import LegalDocumentRead, LegalVersionRead

router = APIRouter()


@router.get("/documents", response_model=list[LegalDocumentRead])
async def list_documents(
    limit: int = Query(default=50, ge=1, le=100),
    offset: int = Query(default=0, ge=0),
    db: AsyncSession = Depends(get_db),
):
    repo = LegalRepository(db)
    return await repo.list_documents(limit=limit, offset=offset)


@router.get(
    "/documents/{document_id}/active-version",
    response_model=LegalVersionRead,
)
async def get_active_version(
    document_id: UUID,
    target_date: date,
    db: AsyncSession = Depends(get_db),
):
    repo = LegalRepository(db)
    version = await repo.get_active_version(document_id, target_date)
    if version is None:
        raise HTTPException(
            status_code=404,
            detail="Для указанной даты действующая редакция не найдена",
        )
    return version
