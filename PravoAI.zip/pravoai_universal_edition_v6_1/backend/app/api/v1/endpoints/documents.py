from __future__ import annotations

import os
import uuid
from pathlib import Path

from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.core.security import get_current_user, require_product_access
from app.db.session import get_db
from app.models.app import UploadedDocument, User
from app.schemas.product import DocumentAskRequest, DocumentRead
from app.services.chat import answer_question
from app.services.files import extract_text, relevant_passages, safe_filename
from app.services.antivirus import AntivirusUnavailable, MalwareDetected, scan_bytes
from app.services.usage import enforce_quota

router = APIRouter()


@router.get("", response_model=list[DocumentRead])
async def list_documents(user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)):
    return list((await db.scalars(select(UploadedDocument).where(UploadedDocument.user_id == user.id).order_by(UploadedDocument.created_at.desc()))).all())


@router.post("/upload", response_model=DocumentRead, status_code=201)
async def upload_document(
    file: UploadFile = File(...),
    case_id: uuid.UUID | None = Form(default=None),
    user: User = Depends(require_product_access),
    db: AsyncSession = Depends(get_db),
):
    await enforce_quota(db, user, "documents")
    data = await file.read()
    if len(data) > settings.max_upload_mb * 1024 * 1024:
        raise HTTPException(413, f"Максимальный размер файла: {settings.max_upload_mb} МБ")
    filename = safe_filename(file.filename or "document")
    try:
        await scan_bytes(data)
    except MalwareDetected as exc:
        raise HTTPException(422, str(exc))
    except AntivirusUnavailable as exc:
        raise HTTPException(503, str(exc))
    try:
        text = extract_text(filename, data)
    except ValueError as exc:
        raise HTTPException(415, str(exc))
    if not text.strip():
        raise HTTPException(422, "Не удалось извлечь текст. Для сканированного PDF потребуется OCR-модуль.")
    Path(settings.upload_dir).mkdir(parents=True, exist_ok=True)
    document_id = uuid.uuid4()
    path = Path(settings.upload_dir) / f"{document_id}_{filename}"
    path.write_bytes(data)
    item = UploadedDocument(
        id=document_id, user_id=user.id, case_id=case_id, filename=filename,
        media_type=file.content_type, size_bytes=len(data), storage_path=str(path),
        text_content=text, status="ready",
    )
    db.add(item); await db.commit(); await db.refresh(item)
    return item


@router.get("/{document_id}/download")
async def download_document(document_id: uuid.UUID, user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)):
    from fastapi.responses import FileResponse
    item = await db.scalar(select(UploadedDocument).where(UploadedDocument.id == document_id, UploadedDocument.user_id == user.id))
    if item is None:
        raise HTTPException(404, "Документ не найден")
    if not os.path.exists(item.storage_path):
        raise HTTPException(404, "Файл отсутствует в хранилище")
    return FileResponse(item.storage_path, media_type=item.media_type or "application/octet-stream", filename=item.filename)


@router.delete("/{document_id}", status_code=204)
async def delete_document(document_id: uuid.UUID, user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)):
    item = await db.scalar(select(UploadedDocument).where(UploadedDocument.id == document_id, UploadedDocument.user_id == user.id))
    if item is None: raise HTTPException(404, "Документ не найден")
    try: os.remove(item.storage_path)
    except FileNotFoundError: pass
    await db.delete(item); await db.commit()


@router.post("/{document_id}/ask")
async def ask_document(document_id: uuid.UUID, payload: DocumentAskRequest, user: User = Depends(require_product_access), db: AsyncSession = Depends(get_db)):
    item = await db.scalar(select(UploadedDocument).where(UploadedDocument.id == document_id, UploadedDocument.user_id == user.id))
    if item is None: raise HTTPException(404, "Документ не найден")
    passages = relevant_passages(item.text_content, payload.question)
    document_context = "\n\n".join(passages)[:7000]
    legal = await answer_question(db, question=payload.question, region=user.region, factual_context=document_context)
    return {
        "document_id": str(item.id),
        "answer": legal.data.get("short_answer") or "По документу найдены релевантные фрагменты и применимые нормы.",
        "document_passages": passages,
        "legal": legal.data,
        "legal_sources": [
            {"chunk_id": str(h.chunk_id), "document": h.document_title, "article": h.article, "source_url": h.source_url, "excerpt": h.text[:900]}
            for h in legal.hits
        ],
    }
