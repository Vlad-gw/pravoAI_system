from __future__ import annotations

from fastapi import APIRouter, Depends, Request
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.security import require_admin
from app.db.session import get_db
from app.models.app import Conversation, Feedback, Message, UploadedDocument, User
from app.models.legal import LegalChunk, LegalDocument, LegalDocumentVersion

router = APIRouter()

from app.schemas.ingestion import IngestFromTextRequest, IngestFromUrlRequest


@router.get("/metrics")
async def metrics(_: User = Depends(require_admin), db: AsyncSession = Depends(get_db)):
    async def count(model):
        return int((await db.scalar(select(func.count()).select_from(model))) or 0)
    low_conf = int((await db.scalar(select(func.count()).select_from(Message).where(Message.confidence == "недостаточно данных"))) or 0)
    assistant_count = int((await db.scalar(select(func.count()).select_from(Message).where(Message.role == "assistant"))) or 0)
    useful = int((await db.scalar(select(func.count()).select_from(Feedback).where(Feedback.useful.is_(True)))) or 0)
    feedback_count = await count(Feedback)
    return {
        "users": await count(User),
        "conversations": await count(Conversation),
        "messages": await count(Message),
        "uploaded_documents": await count(UploadedDocument),
        "legal_documents": await count(LegalDocument),
        "legal_versions": await count(LegalDocumentVersion),
        "legal_chunks": await count(LegalChunk),
        "low_confidence_rate": round(low_conf / assistant_count, 4) if assistant_count else 0,
        "positive_feedback_rate": round(useful / feedback_count, 4) if feedback_count else 0,
    }


@router.get("/rag-debug/{message_id}")
async def rag_debug(message_id: str, _: User = Depends(require_admin), db: AsyncSession = Depends(get_db)):
    from uuid import UUID
    from app.models.app import AnswerSource
    rows = (await db.execute(
        select(Message, AnswerSource, LegalChunk, LegalDocumentVersion, LegalDocument)
        .join(AnswerSource, AnswerSource.message_id == Message.id)
        .join(LegalChunk, LegalChunk.id == AnswerSource.legal_chunk_id)
        .join(LegalDocumentVersion, LegalDocumentVersion.id == LegalChunk.version_id)
        .join(LegalDocument, LegalDocument.id == LegalDocumentVersion.legal_document_id)
        .where(Message.id == UUID(message_id))
        .order_by(AnswerSource.rank)
    )).all()
    return {
        "message": rows[0][0].structured_json if rows else None,
        "retrieval": [
            {
                "rank": row[1].rank,
                "document": row[4].title,
                "article": row[2].article,
                "effective_from": row[3].effective_from,
                "effective_to": row[3].effective_to,
                "text": row[2].text,
            }
            for row in rows
        ],
    }


@router.post("/ingest-text")
async def ingest_text_admin(payload: "IngestFromTextRequest", _: User = Depends(require_admin), db: AsyncSession = Depends(get_db)):
    from dataclasses import asdict
    from app.services.ingestion.service import LegalIngestionService
    result = await LegalIngestionService(db).ingest(
        raw_text=payload.raw_text, document_type=payload.document_type, title=payload.title,
        short_title=payload.short_title, number=payload.number, adoption_date=payload.adoption_date,
        source_name=payload.source_name, source_url=str(payload.source_url), external_id=payload.external_id,
        effective_from=payload.effective_from, revision_date=payload.revision_date,
        publication_date=payload.publication_date, metadata=payload.metadata,
    )
    return asdict(result)


@router.post("/ingest-url")
async def ingest_url_admin(payload: "IngestFromUrlRequest", request: Request, admin_user: User = Depends(require_admin), db: AsyncSession = Depends(get_db)):
    """Production-safe official URL ingestion protected by the admin account.

    The legacy X-Admin-Token endpoints remain useful for local automation, but the
    commercial admin UI must use authenticated RBAC instead of a shared static token.
    """
    from dataclasses import asdict
    from fastapi import HTTPException
    from app.services.audit import audit
    from app.services.ingestion.service import LegalIngestionService
    from app.services.ingestion.source_client import LegalSourceError, fetch_official_text
    try:
        raw_text = await fetch_official_text(str(payload.source_url))
        result = await LegalIngestionService(db).ingest(
            raw_text=raw_text, document_type=payload.document_type, title=payload.title,
            short_title=payload.short_title, number=payload.number, adoption_date=payload.adoption_date,
            source_name=payload.source_name, source_url=str(payload.source_url), external_id=payload.external_id,
            effective_from=payload.effective_from, revision_date=payload.revision_date,
            publication_date=payload.publication_date, metadata=payload.metadata,
        )
        await audit(db, request, "admin.legal_ingest_url", user=admin_user, target_type="legal_document", target_id=result.document_id, metadata={"url": str(payload.source_url), "chunks": result.chunks_count})
        await db.commit()
        return asdict(result)
    except LegalSourceError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc


@router.get("/corpus-status")
async def corpus_status(_: User = Depends(require_admin), db: AsyncSession = Depends(get_db)):
    from sqlalchemy import desc
    from app.models.app import IngestionJob
    starter = int((await db.scalar(select(func.count()).select_from(LegalDocumentVersion).where(LegalDocumentVersion.metadata_json["starter_snapshot"].astext == "true"))) or 0)
    jobs = list((await db.scalars(select(IngestionJob).order_by(desc(IngestionJob.started_at)).limit(10))).all())
    return {
        "documents": int((await db.scalar(select(func.count()).select_from(LegalDocument))) or 0),
        "versions": int((await db.scalar(select(func.count()).select_from(LegalDocumentVersion))) or 0),
        "chunks": int((await db.scalar(select(func.count()).select_from(LegalChunk))) or 0),
        "starter_snapshot_versions": starter,
        "production_ready_corpus": starter == 0 and int((await db.scalar(select(func.count()).select_from(LegalDocument))) or 0) > 0,
        "recent_jobs": [{"id": str(x.id), "source": x.source_name, "status": x.status, "started_at": x.started_at, "finished_at": x.finished_at, "details": x.details_json} for x in jobs],
    }


@router.post("/corpus-watch")
async def corpus_watch(_: User = Depends(require_admin)):
    from app.services.corpus_watch import run_corpus_watch
    return await run_corpus_watch()


@router.get("/users")
async def admin_users(_: User = Depends(require_admin), db: AsyncSession = Depends(get_db)):
    rows = list((await db.scalars(select(User).order_by(User.created_at.desc()).limit(500))).all())
    return [{
        "id": str(x.id), "email": x.email, "full_name": x.full_name, "role": x.role, "plan": x.plan,
        "is_active": x.is_active, "created_at": x.created_at, "last_login_at": x.last_login_at
    } for x in rows]


@router.patch("/users/{user_id}")
async def admin_update_user(user_id: str, payload: dict, request: Request, admin_user: User = Depends(require_admin), db: AsyncSession = Depends(get_db)):
    from uuid import UUID
    target = await db.get(User, UUID(user_id))
    if target is None:
        from fastapi import HTTPException
        raise HTTPException(404, "Пользователь не найден")
    if "plan" in payload:
        if payload["plan"] not in {"free", "pro", "business"}:
            from fastapi import HTTPException
            raise HTTPException(422, "Неизвестный тариф")
        target.plan = payload["plan"]
    if "is_active" in payload:
        target.is_active = bool(payload["is_active"])
    from app.services.audit import audit
    await audit(db, request, "admin.user_updated", user=admin_user, target_type="user", target_id=str(target.id), metadata={"plan": target.plan, "is_active": target.is_active})
    await db.commit()
    return {"id": str(target.id), "email": target.email, "plan": target.plan, "is_active": target.is_active}


@router.get("/audit")
async def admin_audit(_: User = Depends(require_admin), db: AsyncSession = Depends(get_db)):
    from app.models.app import AuditLog
    rows = list((await db.scalars(select(AuditLog).order_by(AuditLog.created_at.desc()).limit(500))).all())
    return [{
        "id": str(x.id), "actor_user_id": str(x.actor_user_id) if x.actor_user_id else None, "action": x.action,
        "target_type": x.target_type, "target_id": x.target_id, "request_id": x.request_id,
        "metadata": x.metadata_json, "created_at": x.created_at
    } for x in rows]
