from __future__ import annotations

import secrets
from dataclasses import asdict

import httpx
from fastapi import APIRouter, Depends, Header, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.db.session import get_db
from app.schemas.ingestion import IngestFromTextRequest, IngestFromUrlRequest, IngestionResponse
from app.services.ingestion.service import LegalIngestionService
from app.services.ingestion.source_client import LegalSourceError, fetch_official_text

router = APIRouter()


def require_admin_token(x_admin_token: str | None = Header(default=None)) -> None:
    if not settings.dev_admin_token:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="DEV_ADMIN_TOKEN не настроен",
        )
    if x_admin_token is None or not secrets.compare_digest(x_admin_token, settings.dev_admin_token):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Неверный admin token")


@router.post("/from-url", response_model=IngestionResponse, dependencies=[Depends(require_admin_token)])
async def ingest_from_url(
    payload: IngestFromUrlRequest,
    db: AsyncSession = Depends(get_db),
):
    try:
        raw_text = await fetch_official_text(str(payload.source_url))
        result = await LegalIngestionService(db).ingest(
            raw_text=raw_text,
            document_type=payload.document_type,
            title=payload.title,
            short_title=payload.short_title,
            number=payload.number,
            adoption_date=payload.adoption_date,
            source_name=payload.source_name,
            source_url=str(payload.source_url),
            external_id=payload.external_id,
            effective_from=payload.effective_from,
            revision_date=payload.revision_date,
            publication_date=payload.publication_date,
            metadata=payload.metadata,
        )
        return IngestionResponse(**asdict(result))
    except LegalSourceError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except httpx.HTTPError as exc:
        raise HTTPException(status_code=502, detail=f"Ошибка загрузки источника: {exc}") from exc
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc


@router.post("/from-text", response_model=IngestionResponse, dependencies=[Depends(require_admin_token)])
async def ingest_from_text(
    payload: IngestFromTextRequest,
    db: AsyncSession = Depends(get_db),
):
    try:
        result = await LegalIngestionService(db).ingest(
            raw_text=payload.raw_text,
            document_type=payload.document_type,
            title=payload.title,
            short_title=payload.short_title,
            number=payload.number,
            adoption_date=payload.adoption_date,
            source_name=payload.source_name,
            source_url=str(payload.source_url),
            external_id=payload.external_id,
            effective_from=payload.effective_from,
            revision_date=payload.revision_date,
            publication_date=payload.publication_date,
            metadata=payload.metadata,
        )
        return IngestionResponse(**asdict(result))
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
