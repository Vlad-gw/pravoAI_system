from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.security import get_current_user, require_product_access
from app.db.session import get_db
from app.models.app import GeneratedDocument, User
from app.schemas.product import GenerateDocumentRequest, GeneratedDocumentRead
from app.services.chat import answer_question
from app.services.usage import enforce_quota

router = APIRouter()

TITLES = {
    "consumer_claim": "Претензия продавцу / исполнителю",
    "employer_application": "Заявление работодателю",
    "request": "Обращение",
    "demand": "Требование",
    "documents_request": "Заявление о предоставлении документов",
    "labor_complaint": "Жалоба по трудовому вопросу",
}


def render(payload: GenerateDocumentRequest, legal: dict, sources: list[dict]) -> tuple[str, str]:
    title = TITLES.get(payload.document_type, "Юридическое обращение")
    lines = [title.upper(), ""]
    if payload.recipient:
        lines += [f"Кому: {payload.recipient}"]
    if payload.applicant:
        lines += [f"От: {payload.applicant}"]
    lines += ["", "ОБСТОЯТЕЛЬСТВА", payload.facts.strip(), ""]
    if sources:
        lines += ["ПРАВОВОЕ ОСНОВАНИЕ"]
        for src in sources[:5]:
            label = src["document"] + (f", ст. {src['article']}" if src.get("article") else "")
            lines += [f"- {label}: {src['explanation']}"]
        lines += [""]
    if payload.demand:
        lines += ["ТРЕБОВАНИЕ", payload.demand.strip(), ""]
    elif legal.get("recommended_actions"):
        lines += ["ПРОШУ / ПРЕДЛАГАЕМЫЕ ДЕЙСТВИЯ"] + [f"- {x}" for x in legal["recommended_actions"][:4]] + [""]
    if payload.attachments:
        lines += ["ПРИЛОЖЕНИЯ"] + [f"- {x}" for x in payload.attachments] + [""]
    lines += [
        "Дата: __________________",
        "Подпись: ________________",
        "",
        "Черновик сформирован ПравоAI по указанным фактам и найденным источникам. Перед подачей проверьте адресата, реквизиты, доказательства, актуальность редакции и процессуальные сроки.",
    ]
    return title, "\n".join(lines)


@router.post("", response_model=GeneratedDocumentRead, status_code=201)
async def generate(payload: GenerateDocumentRequest, user: User = Depends(require_product_access), db: AsyncSession = Depends(get_db)):
    await enforce_quota(db, user, "generations")
    question = f"{payload.facts}\nТребование: {payload.demand or ''}".strip()
    legal_result = await answer_question(db, question=question, region=user.region)
    source_items = legal_result.data.get("legal_basis", [])
    title, content = render(payload, legal_result.data, source_items)
    item = GeneratedDocument(
        user_id=user.id,
        case_id=payload.case_id,
        document_type=payload.document_type,
        title=title,
        content=content,
        metadata_json={
            "template": "commercial-v2",
            "target_date": legal_result.data.get("target_date"),
            "confidence": legal_result.data.get("confidence"),
            "source_ids": [x.get("source_id") for x in source_items if x.get("source_id")],
        },
    )
    db.add(item)
    await db.commit()
    await db.refresh(item)
    return item


@router.get("", response_model=list[GeneratedDocumentRead])
async def list_generated(user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)):
    return list((await db.scalars(select(GeneratedDocument).where(GeneratedDocument.user_id == user.id).order_by(GeneratedDocument.created_at.desc()))).all())


@router.get("/{document_id}/docx")
async def export_docx(document_id: str, user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)):
    import io
    from uuid import UUID
    from fastapi.responses import StreamingResponse
    from docx import Document

    item = await db.scalar(select(GeneratedDocument).where(GeneratedDocument.id == UUID(document_id), GeneratedDocument.user_id == user.id))
    if item is None:
        raise HTTPException(404, "Документ не найден")
    doc = Document()
    for idx, paragraph in enumerate(item.content.split("\n")):
        if idx == 0:
            doc.add_heading(paragraph, level=1)
        else:
            doc.add_paragraph(paragraph)
    buf = io.BytesIO(); doc.save(buf); buf.seek(0)
    return StreamingResponse(buf, media_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document", headers={"Content-Disposition": f'attachment; filename="pravoai_{document_id}.docx"'})


@router.get("/{document_id}/pdf")
async def export_pdf(document_id: str, user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)):
    import io
    from uuid import UUID
    from fastapi.responses import StreamingResponse
    from fpdf import FPDF

    item = await db.scalar(select(GeneratedDocument).where(GeneratedDocument.id == UUID(document_id), GeneratedDocument.user_id == user.id))
    if item is None:
        raise HTTPException(404, "Документ не найден")
    pdf = FPDF()
    pdf.add_page()
    font_path = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"
    pdf.add_font("DejaVu", "", font_path)
    pdf.set_font("DejaVu", size=11)
    for line in item.content.split("\n"):
        pdf.multi_cell(0, 7, line or " ")
    data = bytes(pdf.output())
    return StreamingResponse(io.BytesIO(data), media_type="application/pdf", headers={"Content-Disposition": f'attachment; filename="pravoai_{document_id}.pdf"'})
