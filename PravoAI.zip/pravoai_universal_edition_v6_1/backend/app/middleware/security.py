from __future__ import annotations

import uuid
import logging
import time

from fastapi import Request
from redis.asyncio import Redis
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import JSONResponse

from app.core.config import settings

log = logging.getLogger("pravoai.http")


class RequestSecurityMiddleware(BaseHTTPMiddleware):
    def __init__(self, app):
        super().__init__(app)
        self.redis = Redis.from_url(settings.redis_url, encoding="utf-8", decode_responses=True)

    async def dispatch(self, request: Request, call_next):
        request_id = request.headers.get("x-request-id") or str(uuid.uuid4())
        request.state.request_id = request_id

        if request.method != "OPTIONS":
            allowed = await self._rate_limit(request)
            if not allowed:
                return JSONResponse(
                    {"detail": "Слишком много запросов. Повторите попытку позже.", "request_id": request_id},
                    status_code=429,
                    headers={"Retry-After": "60", "X-Request-ID": request_id},
                )

        started = time.perf_counter()
        response = await call_next(request)
        elapsed_ms = int((time.perf_counter() - started) * 1000)
        log.info("request method=%s path=%s status=%s latency_ms=%s request_id=%s", request.method, request.url.path, response.status_code, elapsed_ms, request_id)
        response.headers["X-Request-ID"] = request_id
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
        response.headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()"
        response.headers["Cross-Origin-Opener-Policy"] = "same-origin"
        # Sensitive legal/account responses must never be cached by shared proxies or browsers.
        if any(prefix in request.url.path for prefix in ("/auth/", "/chat/", "/documents/", "/cases/", "/generated-documents/", "/admin/")):
            response.headers["Cache-Control"] = "no-store, max-age=0"
            response.headers["Pragma"] = "no-cache"
        if settings.is_production:
            response.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
            response.headers["Content-Security-Policy"] = (
                "default-src 'self'; connect-src 'self'; img-src 'self' data:; "
                "style-src 'self' 'unsafe-inline'; script-src 'self'; font-src 'self' data:; "
                "frame-ancestors 'none'; base-uri 'self'; form-action 'self'"
            )
        return response

    async def _rate_limit(self, request: Request) -> bool:
        path = request.url.path
        ip = request.client.host if request.client else "unknown"
        limit = settings.global_rate_limit_per_minute
        bucket = "global"
        if "/auth/login" in path or "/auth/register" in path or "/auth/token" in path:
            limit = settings.auth_rate_limit_per_minute
            bucket = "auth"
        elif "/chat/messages" in path:
            limit = settings.chat_rate_limit_per_minute
            bucket = "chat"
        key = f"ratelimit:{bucket}:{ip}"
        try:
            value = await self.redis.incr(key)
            if value == 1:
                await self.redis.expire(key, 60)
            return value <= limit
        except Exception:
            log.exception("rate limiter unavailable bucket=%s ip=%s", bucket, ip)
            # Login/chat abuse controls fail closed in production; ordinary read paths
            # remain available so a short Redis incident does not take the whole site down.
            if settings.is_production and bucket in {"auth", "chat"}:
                return False
            return True
