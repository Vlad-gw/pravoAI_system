from __future__ import annotations

from functools import lru_cache
from urllib.parse import urlparse

from pydantic import field_validator, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    app_name: str = "ПравоAI"
    app_version: str = "6.1.0-universal"
    api_v1_prefix: str = "/api/v1"
    environment: str = "development"  # development | staging | production
    commercial_mode: bool = True
    public_url: str = "http://localhost:3000"
    support_email: str = "support@example.ru"
    company_name: str = "ООО «ПравоAI»"
    company_inn: str = ""
    company_ogrn: str = ""
    legal_address: str = ""

    database_url: str = "postgresql+asyncpg://pravoai:pravoai_dev_password@db:5432/pravoai"
    redis_url: str = "redis://redis:6379/0"

    embedding_dim: int = 1024
    embedding_provider: str = "auto"  # auto | hash | openai_compatible | ollama
    llm_provider: str = "auto"  # auto | extractive | openai_compatible | ollama
    llm_base_url: str = "https://api.openai.com/v1"
    llm_api_key: str = ""
    llm_model: str = "gpt-5.6"
    ollama_base_url: str = "http://ollama:11434/v1"
    ollama_model: str = "qwen3.5:9b"
    embedding_model: str = "text-embedding-3-small"
    ollama_embedding_model: str = "qwen3-embedding:0.6b"
    local_context_tokens: int = 16384
    embedding_base_url: str = ""  # empty => LLM_BASE_URL
    embedding_api_key: str = ""   # empty => LLM_API_KEY
    embedding_send_dimensions: bool = True
    mask_pii_before_external_llm: bool = True
    allow_extractive_production: bool = False
    allow_hash_embeddings_production: bool = False

    jwt_secret: str = "change-this-before-production"
    jwt_algorithm: str = "HS256"
    access_token_minutes: int = 20
    refresh_token_days: int = 30
    cookie_secure: bool = False
    cookie_domain: str | None = None
    refresh_cookie_name: str = "pravoai_refresh"
    bootstrap_admin_email: str = "admin@pravoai.local"
    bootstrap_admin_password: str = "PravoAI-Admin-2026!"
    enable_bootstrap_admin: bool = True
    dev_admin_token: str = "change-this-local-token"

    terms_version: str = "2026-09-11"
    privacy_version: str = "2026-09-11"
    require_terms_acceptance: bool = True

    # Transactional email. Local demo may leave it disabled; production can require verification.
    email_provider: str = "disabled"  # disabled | smtp
    smtp_host: str = ""
    smtp_port: int = 587
    smtp_username: str = ""
    smtp_password: str = ""
    smtp_from_email: str = ""
    smtp_from_name: str = "ПравоAI"
    smtp_starttls: bool = True
    require_email_verification: bool = False
    verification_token_hours: int = 24
    password_reset_token_minutes: int = 30

    upload_dir: str = "/data/uploads"
    max_upload_mb: int = 25
    antivirus_required: bool = False
    clamav_host: str = ""
    clamav_port: int = 3310
    cors_origins: str = "http://localhost:3000,http://127.0.0.1:3000"
    trusted_hosts: str = "localhost,127.0.0.1"
    enable_docs: bool = True
    seed_starter_corpus: bool = True
    corpus_watch_interval_hours: int = 24
    corpus_manifest_path: str = "/app/app/data/corpus_sources.json"
    audit_retention_days: int = 365
    maintenance_interval_hours: int = 24

    global_rate_limit_per_minute: int = 180
    auth_rate_limit_per_minute: int = 12
    chat_rate_limit_per_minute: int = 40

    free_questions_month: int = 10
    free_documents_month: int = 2
    free_generations_month: int = 1
    pro_questions_month: int = 300
    pro_documents_month: int = 50
    pro_generations_month: int = 30
    business_questions_month: int = 2000
    business_documents_month: int = 500
    business_generations_month: int = 200

    billing_provider: str = "disabled"  # disabled | mock | yookassa
    yookassa_shop_id: str = ""
    yookassa_secret_key: str = ""
    yookassa_return_url: str = "http://localhost:3000/?payment=return"
    yookassa_receipt_enabled: bool = False
    yookassa_vat_code: int = 1
    pro_price_kopecks: int = 99000
    business_price_kopecks: int = 299000
    subscription_days: int = 30

    model_config = SettingsConfigDict(env_file=".env", extra="ignore", case_sensitive=False)

    @property
    def is_production(self) -> bool:
        return self.environment.lower() == "production"

    @property
    def cors_origin_list(self) -> list[str]:
        return [x.strip() for x in self.cors_origins.split(",") if x.strip()]

    @property
    def trusted_host_list(self) -> list[str]:
        return [x.strip() for x in self.trusted_hosts.split(",") if x.strip()]

    @model_validator(mode="after")
    def production_guardrails(self):
        if self.is_production:
            bad = []
            if len(self.jwt_secret) < 48 or "change-this" in self.jwt_secret:
                bad.append("JWT_SECRET must be a random string of at least 48 characters")
            if self.enable_bootstrap_admin and self.bootstrap_admin_password == "PravoAI-Admin-2026!":
                bad.append("BOOTSTRAP_ADMIN_PASSWORD must be changed or bootstrap admin disabled")
            if self.database_url.find("pravoai_dev_password") >= 0:
                bad.append("production database password is still the development default")
            if self.public_url.startswith("http://"):
                bad.append("PUBLIC_URL must use HTTPS in production")
            if self.cookie_secure is not True:
                bad.append("COOKIE_SECURE=true is required in production")
            if self.enable_docs:
                bad.append("ENABLE_DOCS=false is recommended/required by this distribution in production")
            if self.seed_starter_corpus:
                bad.append("SEED_STARTER_CORPUS=false is required in production; load a verified official corpus")
            if self.commercial_mode and self.billing_provider != "yookassa":
                bad.append("BILLING_PROVIDER=yookassa is required for this commercial production distribution")
            if self.llm_provider == "extractive" and not self.allow_extractive_production:
                bad.append("production requires a reviewed LLM endpoint, or explicitly set ALLOW_EXTRACTIVE_PRODUCTION=true")
            if self.embedding_provider == "hash" and not self.allow_hash_embeddings_production:
                bad.append("production requires real embeddings, or explicitly set ALLOW_HASH_EMBEDDINGS_PRODUCTION=true")
            if self.llm_provider == "openai_compatible" and not self.llm_api_key:
                bad.append("LLM_API_KEY is empty while external LLM is enabled")
            if self.embedding_provider == "openai_compatible" and not (self.embedding_api_key or self.llm_api_key):
                bad.append("EMBEDDING_API_KEY (or LLM_API_KEY fallback) is empty while external embeddings are enabled")
            if self.billing_provider == "yookassa" and (not self.yookassa_shop_id or not self.yookassa_secret_key):
                bad.append("YooKassa credentials are required when BILLING_PROVIDER=yookassa")
            if self.require_email_verification:
                if self.email_provider != "smtp":
                    bad.append("EMAIL_PROVIDER=smtp is required when email verification is enabled")
                if not self.smtp_host or not self.smtp_from_email:
                    bad.append("SMTP_HOST and SMTP_FROM_EMAIL are required when email verification is enabled")
            if self.antivirus_required and not self.clamav_host:
                bad.append("CLAMAV_HOST is required when ANTIVIRUS_REQUIRED=true")
            if not self.company_inn or not self.company_ogrn or not self.legal_address:
                bad.append("COMPANY_INN, COMPANY_OGRN and LEGAL_ADDRESS must be filled before commercial launch")
            if "example" in self.support_email.lower():
                bad.append("SUPPORT_EMAIL must be a real support address")
            if "change_me" in self.terms_version.lower() or "change_me" in self.privacy_version.lower():
                bad.append("TERMS_VERSION and PRIVACY_VERSION must be finalized after legal review")
            if bad:
                raise ValueError("Production configuration is unsafe: " + "; ".join(bad))
        return self


settings = Settings()
