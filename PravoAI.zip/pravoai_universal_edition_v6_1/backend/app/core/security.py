from __future__ import annotations

from datetime import datetime, timedelta, timezone
import hashlib
import secrets
import uuid

import jwt
from fastapi import Depends, HTTPException, Request, Response, status
from fastapi.security import OAuth2PasswordBearer
from pwdlib import PasswordHash
from sqlalchemy import select, update
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.db.session import get_db
from app.models.app import RefreshSession, User

password_hash = PasswordHash.recommended()
oauth2_scheme = OAuth2PasswordBearer(tokenUrl=f"{settings.api_v1_prefix}/auth/token", auto_error=False)


def hash_password(password: str) -> str:
    return password_hash.hash(password)


def verify_password(password: str, hashed: str) -> bool:
    return password_hash.verify(password, hashed)


def validate_password_strength(password: str) -> None:
    if len(password) < 10:
        raise HTTPException(status_code=422, detail="Пароль должен содержать не менее 10 символов")
    if not any(ch.isalpha() for ch in password) or not any(ch.isdigit() for ch in password):
        raise HTTPException(status_code=422, detail="Пароль должен содержать буквы и цифры")


def create_access_token(user: User) -> str:
    now = datetime.now(timezone.utc)
    payload = {
        "sub": str(user.id),
        "role": user.role,
        "plan": user.plan,
        "ver": user.token_version,
        "iat": now,
        "exp": now + timedelta(minutes=settings.access_token_minutes),
        "type": "access",
    }
    return jwt.encode(payload, settings.jwt_secret, algorithm=settings.jwt_algorithm)


def _token_hash(raw: str) -> str:
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def _ip_hash(request: Request) -> str | None:
    ip = request.client.host if request.client else None
    return hashlib.sha256((ip or "unknown").encode()).hexdigest() if ip else None


async def create_refresh_session(db: AsyncSession, user: User, request: Request) -> str:
    raw = secrets.token_urlsafe(48)
    session = RefreshSession(
        user_id=user.id,
        token_hash=_token_hash(raw),
        user_agent=(request.headers.get("user-agent") or "")[:500] or None,
        ip_hash=_ip_hash(request),
        expires_at=datetime.now(timezone.utc) + timedelta(days=settings.refresh_token_days),
    )
    db.add(session)
    await db.flush()
    return raw


def set_refresh_cookie(response: Response, raw: str) -> None:
    response.set_cookie(
        key=settings.refresh_cookie_name,
        value=raw,
        max_age=settings.refresh_token_days * 86400,
        httponly=True,
        secure=settings.cookie_secure,
        samesite="lax",
        domain=settings.cookie_domain,
        path=f"{settings.api_v1_prefix}/auth",
    )


def clear_refresh_cookie(response: Response) -> None:
    response.delete_cookie(
        key=settings.refresh_cookie_name,
        domain=settings.cookie_domain,
        path=f"{settings.api_v1_prefix}/auth",
    )


async def rotate_refresh_session(db: AsyncSession, raw: str, request: Request) -> tuple[User, str]:
    now = datetime.now(timezone.utc)
    row = await db.scalar(
        select(RefreshSession).where(
            RefreshSession.token_hash == _token_hash(raw),
            RefreshSession.revoked_at.is_(None),
            RefreshSession.expires_at > now,
        )
    )
    if row is None:
        raise HTTPException(status_code=401, detail="Сессия истекла. Войдите снова")
    user = await db.scalar(select(User).where(User.id == row.user_id, User.is_active.is_(True), User.deleted_at.is_(None)))
    if user is None:
        raise HTTPException(status_code=401, detail="Сессия недействительна")
    row.revoked_at = now
    new_raw = await create_refresh_session(db, user, request)
    return user, new_raw


async def revoke_refresh_session(db: AsyncSession, raw: str | None) -> None:
    if not raw:
        return
    await db.execute(
        update(RefreshSession)
        .where(RefreshSession.token_hash == _token_hash(raw), RefreshSession.revoked_at.is_(None))
        .values(revoked_at=datetime.now(timezone.utc))
    )


async def revoke_all_user_sessions(db: AsyncSession, user: User) -> None:
    user.token_version += 1
    await db.execute(
        update(RefreshSession)
        .where(RefreshSession.user_id == user.id, RefreshSession.revoked_at.is_(None))
        .values(revoked_at=datetime.now(timezone.utc))
    )


async def get_current_user(
    token: str | None = Depends(oauth2_scheme), db: AsyncSession = Depends(get_db)
) -> User:
    credentials_error = HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Недействительная сессия")
    if not token:
        raise credentials_error
    try:
        payload = jwt.decode(token, settings.jwt_secret, algorithms=[settings.jwt_algorithm])
        if payload.get("type") != "access":
            raise ValueError("wrong token type")
        user_id = uuid.UUID(payload.get("sub", ""))
        version = int(payload.get("ver", -1))
    except Exception:
        raise credentials_error
    user = await db.scalar(
        select(User).where(User.id == user_id, User.is_active.is_(True), User.deleted_at.is_(None))
    )
    if user is None or user.token_version != version:
        raise credentials_error
    return user


async def require_admin(user: User = Depends(get_current_user)) -> User:
    if user.role != "admin":
        raise HTTPException(status_code=403, detail="Требуются права администратора")
    return user


async def require_product_access(user: User = Depends(get_current_user)) -> User:
    """Server-side gate for features that consume AI/resources."""
    if settings.require_terms_acceptance and (
        user.terms_version != settings.terms_version or user.privacy_version != settings.privacy_version
    ):
        raise HTTPException(status_code=428, detail="Необходимо принять актуальные условия использования и политику")
    if settings.require_email_verification and user.role != "admin" and user.email_verified_at is None:
        raise HTTPException(status_code=403, detail="Подтвердите email, чтобы пользоваться сервисом")
    return user
