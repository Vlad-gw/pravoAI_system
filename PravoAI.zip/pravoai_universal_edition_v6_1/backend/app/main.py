from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from starlette.middleware.trustedhost import TrustedHostMiddleware

from app.api.v1.router import api_router
from app.core.config import settings
from app.middleware.security import RequestSecurityMiddleware
from app.services.bootstrap import ensure_bootstrap_admin
from app.services.starter_seed import ensure_starter_legal_corpus


@asynccontextmanager
async def lifespan(app: FastAPI):
    Path(settings.upload_dir).mkdir(parents=True, exist_ok=True)
    if settings.enable_bootstrap_admin:
        await ensure_bootstrap_admin()
    if settings.seed_starter_corpus:
        await ensure_starter_legal_corpus()
    yield


def create_app() -> FastAPI:
    application = FastAPI(
        title=settings.app_name,
        version=settings.app_version,
        description="Commercial Legal AI / RAG: versioned law corpus, grounded answers, documents, billing and privacy controls.",
        lifespan=lifespan,
        docs_url="/docs" if settings.enable_docs else None,
        redoc_url="/redoc" if settings.enable_docs else None,
        openapi_url="/openapi.json" if settings.enable_docs else None,
    )
    application.add_middleware(TrustedHostMiddleware, allowed_hosts=settings.trusted_host_list or ["*"])
    application.add_middleware(RequestSecurityMiddleware)
    application.add_middleware(
        CORSMiddleware,
        allow_origins=settings.cors_origin_list,
        allow_credentials=True,
        allow_methods=["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
        allow_headers=["Authorization", "Content-Type", "X-Request-ID", "X-Admin-Token"],
    )

    @application.exception_handler(Exception)
    async def unhandled(request: Request, exc: Exception):
        # Do not leak stack traces or database details to public clients.
        if settings.environment == "development":
            raise exc
        return JSONResponse(
            status_code=500,
            content={"detail": "Внутренняя ошибка сервиса", "request_id": getattr(request.state, "request_id", None)},
        )

    application.include_router(api_router, prefix=settings.api_v1_prefix)
    return application


app = create_app()
