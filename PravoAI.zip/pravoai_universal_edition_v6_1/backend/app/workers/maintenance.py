from __future__ import annotations
import asyncio
import logging
from datetime import datetime, timedelta, timezone
from sqlalchemy import delete
from app.core.config import settings
from app.db.session import AsyncSessionLocal
from app.models.app import AuditLog, EmailToken, RefreshSession

logging.basicConfig(level=logging.INFO)
log = logging.getLogger("pravoai.maintenance")

async def cleanup_once():
    now = datetime.now(timezone.utc)
    async with AsyncSessionLocal() as db:
        sessions = await db.execute(delete(RefreshSession).where(RefreshSession.expires_at < now - timedelta(days=7)))
        emails = await db.execute(delete(EmailToken).where(EmailToken.expires_at < now - timedelta(days=7)))
        audits = await db.execute(delete(AuditLog).where(AuditLog.created_at < now - timedelta(days=settings.audit_retention_days)))
        await db.commit()
        log.info("cleanup refresh=%s email_tokens=%s audit=%s", sessions.rowcount, emails.rowcount, audits.rowcount)

async def main():
    while True:
        try:
            await cleanup_once()
        except Exception:
            log.exception("maintenance failed")
        await asyncio.sleep(max(1, settings.maintenance_interval_hours) * 3600)

if __name__ == "__main__":
    asyncio.run(main())
