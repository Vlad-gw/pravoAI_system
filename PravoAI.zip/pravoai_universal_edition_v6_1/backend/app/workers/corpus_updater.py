from __future__ import annotations
import asyncio
import logging
from app.core.config import settings
from app.services.corpus_watch import run_corpus_watch

logging.basicConfig(level=logging.INFO)
log = logging.getLogger("pravoai.corpus_watch")

async def main():
    while True:
        try:
            result = await run_corpus_watch()
            log.info("Corpus watch: %s", result)
        except Exception:
            log.exception("Corpus watch failed")
        await asyncio.sleep(max(1, settings.corpus_watch_interval_hours) * 3600)

if __name__ == "__main__":
    asyncio.run(main())
