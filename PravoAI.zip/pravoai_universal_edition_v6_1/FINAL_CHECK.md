# Final check — Universal Edition 6.1

Выполнено перед упаковкой:

- `python -m compileall` backend — OK;
- shell syntax (`start.command`, `stop.command`, `verify.command`) — OK;
- Docker Compose YAML — OK;
- 25 выбранных unit/regression tests с локальным pgvector stub — passed;
- TypeScript parser check — без синтаксических ошибок (в среде сборки отсутствуют node_modules, поэтому module/type resolution здесь не выполнялся);
- universal router: Python/обычный вопрос → general;
- legal router: трудовой/потребительский вопрос → legal;
- legal follow-up `я ответил` сохраняет контекст;
- pension/severance regression — ст. 178/140 и договорное основание разделены.

Полный контейнерный smoke test выполняется на машине пользователя командой `./verify.command`, так как текущая среда артефакта не имеет Docker daemon.

- отдельный smoke-test router/context: новый короткий общий вопрос после юридической темы переключается в general; follow-up «я ответил» сохраняет legal context — OK.
