#!/bin/sh
set -eu
mkdir -p /backups
STAMP=$(date +%Y%m%d_%H%M%S)
PGPASSWORD="$POSTGRES_PASSWORD" pg_dump -h db -U "$POSTGRES_USER" -d "$POSTGRES_DB" -Fc > "/backups/pravoai_${STAMP}.dump"
find /backups -type f -name 'pravoai_*.dump' -mtime +"${BACKUP_RETENTION_DAYS:-14}" -delete
