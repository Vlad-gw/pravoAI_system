#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"

pause_on_error(){
  local code=$?
  if [ "$code" -ne 0 ]; then
    echo ""
    echo "❌ Запуск ПравоAI завершился с ошибкой (код $code)."
    echo "   Диагностика: docker compose ps && docker compose logs --tail=120 api frontend"
    read -r -p "Нажмите Enter для выхода..." || true
  fi
  exit "$code"
}
trap pause_on_error EXIT

retry(){
  local attempts="$1"; shift
  local delay="$1"; shift
  local n=1
  until "$@"; do
    local code=$?
    if [ "$n" -ge "$attempts" ]; then return "$code"; fi
    echo "⚠️ Операция не удалась (попытка $n/$attempts). Повтор через ${delay}с..."
    sleep "$delay"; n=$((n+1)); delay=$((delay*2))
  done
}

if ! command -v docker >/dev/null 2>&1; then
  echo "❌ Docker не найден. Установите Docker Desktop и повторите."
  exit 1
fi
if ! docker info >/dev/null 2>&1; then
  echo "❌ Docker Desktop не запущен."
  exit 1
fi

[ -f .env ] || cp .env.example .env

docker compose --profile docker-ai down --remove-orphans >/dev/null 2>&1 || true
for old_project in pravoai_mvp pravoai_full_mvp pravoai_ready_edition pravoai_chat_edition_v3_1 pravoai_chat_edition_v3_2 pravoai_chat_edition_v3_3; do
  if docker ps -aq --filter "label=com.docker.compose.project=$old_project" | grep -q .; then
    docker compose -p "$old_project" down --remove-orphans >/dev/null 2>&1 || true
  fi
done

# ---- AI runtime -----------------------------------------------------------
# On Apple Silicon a native Ollama uses Metal and is dramatically faster than
# Ollama inside Docker. We prefer it automatically and keep Docker as fallback.
OLLAMA_BIN=""
for candidate in "$(command -v ollama 2>/dev/null || true)" \
  /Applications/Ollama.app/Contents/Resources/ollama \
  /opt/homebrew/bin/ollama /usr/local/bin/ollama; do
  if [ -n "$candidate" ] && [ -x "$candidate" ]; then OLLAMA_BIN="$candidate"; break; fi
done

if [ "$(uname -s)" = "Darwin" ] && [ "$(uname -m)" = "arm64" ] && [ -z "$OLLAMA_BIN" ] && command -v brew >/dev/null 2>&1; then
  echo "⚡ Для быстрых ответов на Apple Silicon нужен нативный Ollama. Устанавливаю через Homebrew..."
  if retry 2 5 brew install ollama >/dev/null 2>&1; then
    OLLAMA_BIN="$(command -v ollama 2>/dev/null || true)"
  else
    echo "⚠️ Нативный Ollama установить не удалось — использую Docker-режим."
  fi
fi

USE_NATIVE=0
MODEL="qwen3.5:4b"
EMBED_MODEL="qwen3-embedding:0.6b"

if [ -n "$OLLAMA_BIN" ] && [ "$(uname -s)" = "Darwin" ]; then
  HOST_MEM=$(sysctl -n hw.memsize 2>/dev/null || echo 0)
  # Use the strongest model that leaves reasonable headroom for macOS/Docker.
  if [ "$HOST_MEM" -ge 32000000000 ]; then
    MODEL="qwen3.5:27b"
  elif [ "$HOST_MEM" -ge 16000000000 ]; then
    MODEL="qwen3.5:9b"
  fi
  echo "⚡ Использую нативный Ollama/Metal: $MODEL"
  if ! curl -fsS http://127.0.0.1:11434/api/tags >/dev/null 2>&1; then
    nohup "$OLLAMA_BIN" serve >/tmp/pravoai_ollama.log 2>&1 &
    for i in {1..30}; do
      curl -fsS http://127.0.0.1:11434/api/tags >/dev/null 2>&1 && break
      sleep 1
    done
  fi
  if curl -fsS http://127.0.0.1:11434/api/tags >/dev/null 2>&1; then
    MODELS="$($OLLAMA_BIN list 2>/dev/null || true)"
    NATIVE_OK=1
    if ! printf "%s" "$MODELS" | grep -q "$MODEL"; then
      echo "⬇️ Загружаю основную модель $MODEL (один раз)..."
      if ! retry 4 5 "$OLLAMA_BIN" pull "$MODEL"; then NATIVE_OK=0; fi
    fi
    MODELS="$($OLLAMA_BIN list 2>/dev/null || true)"
    if [ "$NATIVE_OK" -eq 1 ] && ! printf "%s" "$MODELS" | grep -q "$EMBED_MODEL"; then
      echo "⬇️ Загружаю embedding-модель $EMBED_MODEL..."
      if ! retry 4 5 "$OLLAMA_BIN" pull "$EMBED_MODEL"; then NATIVE_OK=0; fi
    fi
    if [ "$NATIVE_OK" -eq 1 ]; then
      USE_NATIVE=1
      export PRAVOAI_OLLAMA_BASE_URL="http://host.docker.internal:11434/v1"
    else
      echo "⚠️ Нативный AI не удалось полностью подготовить — переключаюсь на Docker fallback."
    fi
  fi
fi

if [ "$USE_NATIVE" -ne 1 ]; then
  DOCKER_MEM=$(docker info --format '{{.MemTotal}}' 2>/dev/null || echo 0)
  if [ "$DOCKER_MEM" -ge 28000000000 ]; then
    MODEL="qwen3.5:27b"
  elif [ "$DOCKER_MEM" -ge 12000000000 ]; then
    MODEL="qwen3.5:9b"
  else
    MODEL="qwen3.5:4b"
  fi
  echo "🤖 Использую Docker Ollama: $MODEL (на macOS это медленнее нативного режима)"
  retry 4 3 docker compose --profile docker-ai up -d ollama
  for i in {1..60}; do
    if docker compose --profile docker-ai exec -T ollama ollama list >/dev/null 2>&1; then break; fi
    [ "$i" -eq 60 ] && { echo "❌ Ollama не запустился"; exit 1; }
    sleep 1
  done
  MODELS="$(docker compose --profile docker-ai exec -T ollama ollama list 2>/dev/null || true)"
  if ! printf "%s" "$MODELS" | grep -q "$MODEL"; then
    echo "⬇️ Загружаю $MODEL..."
    retry 4 5 docker compose --profile docker-ai exec -T ollama ollama pull "$MODEL"
  fi
  MODELS="$(docker compose --profile docker-ai exec -T ollama ollama list 2>/dev/null || true)"
  if ! printf "%s" "$MODELS" | grep -q "$EMBED_MODEL"; then
    echo "⬇️ Загружаю $EMBED_MODEL..."
    retry 4 5 docker compose --profile docker-ai exec -T ollama ollama pull "$EMBED_MODEL"
  fi
  export PRAVOAI_OLLAMA_BASE_URL="http://ollama:11434/v1"
fi

export PRAVOAI_RUNTIME_MODEL="$MODEL"
export PRAVOAI_EMBED_MODEL="$EMBED_MODEL"
echo "✅ AI runtime готов: $MODEL"

# ---- App ------------------------------------------------------------------
API_IMAGE="pravoai_chat_edition-api"
if docker image inspect "$API_IMAGE" >/dev/null 2>&1; then
  echo "♻️ Использую локальный backend-образ; актуальный Python-код смонтируется из архива."
else
  echo "▶ Backend-образ отсутствует — собираю впервые..."
  retry 4 5 docker compose build --pull=false api
fi

echo "🎨 Собираю интерфейс v6..."
frontend_ok=0
for attempt in 1 2 3; do
  if docker compose build --pull=false frontend; then frontend_ok=1; break; fi
  echo "⚠️ Сборка frontend не удалась. Повтор..."; sleep $((attempt*4))
done
[ "$frontend_ok" -eq 1 ] || { echo "❌ Не удалось собрать frontend"; exit 1; }

docker compose up -d db redis api frontend

echo "⏳ Жду готовности API..."
for i in {1..90}; do
  if curl -fsS http://localhost:8000/api/v1/ready >/dev/null 2>&1; then
    echo "✅ Backend и правовая база готовы"; break
  fi
  [ "$i" -eq 90 ] && { docker compose logs --tail=120 api; exit 1; }
  sleep 2
done

echo "🧠 Синхронизирую векторный индекс..."
if retry 3 3 docker compose exec -T api python -m app.cli.reembed_corpus; then
  echo "✅ Neural embeddings готовы"
else
  echo "⚠️ Embeddings не перестроились; полнотекстовый поиск и ИИ всё равно доступны."
fi

for i in {1..45}; do
  curl -fsS http://localhost:3000 >/dev/null 2>&1 && break
  [ "$i" -eq 45 ] && { echo "❌ Frontend не ответил"; exit 1; }
  sleep 1
done

echo ""
echo "✅ ПравоAI Universal запущен"
echo "   Интерфейс: http://localhost:3000"
echo "   Swagger:   http://localhost:8000/docs"
echo "   AI-модель: $MODEL"
[ "$USE_NATIVE" -eq 1 ] && echo "   Ускорение: Apple Metal (native Ollama)" || echo "   Ускорение: Docker/CPU fallback"
echo ""
echo "Администратор: admin@pravoai.local"
echo "Пароль: PravoAI-Admin-2026!"

trap - EXIT
if command -v open >/dev/null 2>&1; then sleep 1; open http://localhost:3000; fi
