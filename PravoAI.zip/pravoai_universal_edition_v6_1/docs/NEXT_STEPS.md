# Next steps after purchasing/deploying this release

1. Fill `.env.production` with real organization/infrastructure values.
2. Run `preflight-production.command`.
3. Deploy behind the configured domain.
4. Replace demo corpus with verified official production corpus.
5. Connect reviewed LLM/embedding endpoint.
6. Test SMTP recovery and email verification.
7. Test YooKassa in the chosen payment/receipt scenario.
8. Perform backup restore drill.
9. Have a lawyer review public documents and the Golden Dataset.
10. Open traffic gradually and use user feedback/RAG debug to expand regression tests.
