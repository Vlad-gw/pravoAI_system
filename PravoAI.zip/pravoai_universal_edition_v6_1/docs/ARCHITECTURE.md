# Architecture 6.0

```text
Browser chat
   ↓
FastAPI /chat/messages
   ↓
Conversation memory + attached docs
   ↓
Universal Router
   ├── GENERAL → Qwen3.5 / external LLM → answer
   └── LEGAL
        ↓
      date/area detection
        ↓
      hybrid Legal RAG
      (lexical + vectors + article pins + temporal filter)
        ↓
      Qwen3.5 / external LLM
        ↓
      citation validator
        ↓
      legal answer + verified source panel
```

Assistant messages from history may be conversational context, but never become a source of law. Legal claims can cite only retrieved legal chunks.
