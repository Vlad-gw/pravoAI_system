# Sale / Launch readiness checklist

Этот список разделяет **готовность к продаже исходного продукта** и **готовность конкретного SaaS-инстанса к публичной эксплуатации**.

## A. Техническая поставка

- [x] Backend/API
- [x] Frontend
- [x] PostgreSQL + pgvector
- [x] Redis
- [x] versioned legal corpus
- [x] temporal retrieval
- [x] citation validation
- [x] answer quality guardrails
- [x] gibberish protection
- [x] document upload validation
- [x] ClamAV production integration
- [x] auth + refresh rotation/revocation
- [x] email verification/password recovery integration
- [x] privacy/account export/delete
- [x] separate consent records
- [x] plans/quotas
- [x] YooKassa integration
- [x] admin/audit/corpus monitoring
- [x] HTTPS reference deployment
- [x] backups
- [x] production preflight
- [x] health/readiness
- [x] rate limiting/security headers

## B. Ответы и правовой контент

Перед публичным запуском владелец обязан подтвердить:

- [ ] starter/demo corpus отключен;
- [ ] загружен полный выбранный production corpus;
- [ ] source URL каждого акта проверен;
- [ ] temporal metadata проверены;
- [ ] нет актуальных норм с ошибочно закрытым/открытым периодом;
- [ ] Golden Dataset проверен юристом;
- [ ] протестированы ключевые сценарии продукта;
- [ ] предусмотрена процедура исправления ошибочного ответа;
- [ ] назначен ответственный за обновления корпуса.

## C. Организация / право / privacy

Заполнить и проверить на реальной организации:

- [ ] ИП/ООО и реквизиты;
- [ ] поддержка и официальный email;
- [ ] домен;
- [ ] фактическая privacy/data-flow схема;
- [ ] место хранения персональных данных;
- [ ] поставщик LLM и условия обработки данных;
- [ ] необходимость/условия трансграничной передачи;
- [ ] политика обработки ПД;
- [ ] отдельное согласие на обработку ПД;
- [ ] пользовательские условия/оферта;
- [ ] политика возвратов;
- [ ] сроки хранения/удаления;
- [ ] договоры с обработчиками/подрядчиками при необходимости;
- [ ] юридическая проверка всех публичных текстов.

ZIP не может автоматически подтвердить соответствие конкретной организации законодательству — это зависит от фактической инфраструктуры и бизнес-процессов.

## D. Платежи

- [ ] production YooKassa shop id/key;
- [ ] webhook endpoint доступен снаружи;
- [ ] sandbox/тестовые платежи прошли;
- [ ] корректно обрабатывается повторный webhook;
- [ ] статус платежа перепроверяется у провайдера;
- [ ] чек/receipt/KKT схема согласована с налоговым режимом;
- [ ] цена/НДС/описание услуги проверены;
- [ ] refund/support процесс описан;
- [ ] recurring не включен без отдельной готовой схемы.

## E. Security / operations

- [ ] случайные production secrets;
- [ ] default admin password отсутствует;
- [ ] Swagger отключен;
- [ ] HTTPS работает;
- [ ] CORS/trusted hosts ограничены;
- [ ] ClamAV healthy;
- [ ] upload fail-closed при недоступности antivirus;
- [ ] rate limits проверены;
- [ ] SMTP recovery flow проверен;
- [ ] backup создается;
- [ ] restore drill выполнен;
- [ ] внешний backup существует;
- [ ] мониторинг/alerting подключен к вашей инфраструктуре;
- [ ] обновления образов/OS планируются;
- [ ] incident response контакт назначен.

## F. Product

- [ ] email verification письмо приходит и ссылка работает;
- [ ] forgot/reset password работает;
- [ ] Free quota блокирует сверх лимита;
- [ ] Pro/Business payment активирует тариф;
- [ ] account export работает;
- [ ] account deletion работает;
- [ ] документы удаляются физически из storage;
- [ ] privacy/terms доступны без входа;
- [ ] mobile UI проверен;
- [ ] браузеры Safari/Chrome/Firefox smoke-tested;
- [ ] чат на gibberish не выдает статьи;
- [ ] чат на зарплату не показывает потребительское право;
- [ ] sidebar источников совпадает с legal basis.

## Release decision

Публичный SaaS можно считать готовым к открытию только после выполнения пунктов B–F, относящихся к вашему реальному окружению.
