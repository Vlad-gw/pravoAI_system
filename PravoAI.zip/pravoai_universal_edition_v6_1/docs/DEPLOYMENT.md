# Production deployment

Ниже — reference deployment для одного VPS/VM. Для высокой нагрузки сервисы можно разнести, не меняя API-контракт.

## 1. DNS

Создайте A/AAAA запись домена на production host. Откройте 80/443.

## 2. Подготовка

```bash
git clone / распаковать release
cd pravoai_commercial_final
cp .env.production.example .env.production
./generate-secrets.command
```

Заполните `.env.production`.

Никогда не добавляйте `.env.production` в git/release archive.

## 3. Preflight

```bash
./preflight-production.command
```

Проверяются placeholder-значения и ключевые security/commercial настройки, затем syntax compose config.

## 4. Запуск

```bash
./deploy-production.sh
```

Stack:

- Caddy — TLS/edge;
- nginx frontend;
- FastAPI API;
- PostgreSQL + pgvector;
- Redis;
- ClamAV;
- corpus-watch worker;
- maintenance worker;
- backup worker.

## 5. Проверка

```bash
curl -fsS https://YOUR_DOMAIN/api/v1/health
curl -fsS https://YOUR_DOMAIN/api/v1/ready
```

`ready` не должен становиться production-ready, если остался demo corpus.

## 6. Первый administrator

Рекомендуется создать bootstrap admin только на закрытом initial deployment, затем выключить bootstrap и перезапустить. Не использовать dev credentials.

## 7. Правовая база

Загрузите production corpus через admin panel/API. Только после удаления/отсутствия starter snapshot readiness должен считаться готовым.

## 8. Backups

Backup worker выполняет `pg_dump` в volume `backups` раз в сутки.

Проверка наличия:

```bash
docker compose -f docker-compose.production.yml exec backup sh -lc 'ls -lh /backups'
```

### Обязательный restore drill

Не считайте backup проверенным, пока не выполнили восстановление на отдельной тестовой базе:

```bash
# Примерная схема: точные имена контейнеров/файлов подставляются по месту.
createdb pravoai_restore_test
psql pravoai_restore_test < backup.sql
```

Затем проверить:

- users/count;
- legal documents/versions/chunks;
- conversations/messages;
- alembic revision;
- выборочные документы.

Для серьезного production храните копию backup вне единственного сервера и используйте шифрование/контроль доступа.

## 9. Обновление

Перед release:

1. сделать backup;
2. проверить release notes и migrations;
3. `docker compose ... build`;
4. запустить migrations;
5. smoke test `/health`, `/ready`, login, chat, upload, payment sandbox;
6. следить за логами.

## 10. Incident checklist

При подозрении на компрометацию:

- отключить public access;
- ротировать JWT / DB / Redis / SMTP / YooKassa / LLM secrets;
- завершить refresh sessions;
- сохранить audit logs;
- оценить масштаб затронутых данных;
- действовать по требованиям применимого законодательства и внутренних процедур.
