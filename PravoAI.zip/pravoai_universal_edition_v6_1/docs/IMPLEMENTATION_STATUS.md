# Implementation status — 2.2.0-ready

## Implemented

Legal/RAG: versioned corpus, temporal retrieval, hybrid lexical/vector search, legal-area filtering, reranking, grounded structured answer, strict citation validation, quality guardrails, PII masking.

Product: auth, rotating refresh sessions, email verification/recovery, consent history, chat/history/cases, document upload/OCR/Q&A, generated documents DOCX/PDF, feedback, profile, export/delete account.

Commercial: Free/Pro/Business quotas, YooKassa checkout/webhook verification, public terms/privacy/consent/refund pages.

Admin/ops: metrics, users/plans, corpus status, RAG debug, official URL/text ingestion, audit, corpus watcher, maintenance, ClamAV, backups, Caddy HTTPS, rate limiting, readiness/preflight.

## External launch prerequisites

These cannot be truthfully prefilled in a distributable archive: real legal entity details, domain/DNS, SMTP, YooKassa/KKT configuration, reviewed LLM/data-hosting arrangement, verified full official corpus, legal review of public documents, tested restore procedure and lawyer-reviewed Golden Dataset.

See `SALE_READY_CHECKLIST.md`.
