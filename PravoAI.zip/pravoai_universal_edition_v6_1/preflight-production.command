#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"

ENV_FILE=".env.production"
if [ ! -f "$ENV_FILE" ]; then
  echo "❌ Нет $ENV_FILE. Скопируйте .env.production.example и заполните его."
  exit 1
fi
if grep -q 'CHANGE_ME' "$ENV_FILE"; then
  echo "❌ В $ENV_FILE остались CHANGE_ME значения. Публичный запуск заблокирован."
  exit 1
fi

python3 - <<'PY'
from pathlib import Path
import sys
p=Path('.env.production')
data={}
for raw in p.read_text().splitlines():
    line=raw.strip()
    if not line or line.startswith('#') or '=' not in line:
        continue
    k,v=line.split('=',1); data[k.strip()]=v.strip()
errors=[]
def need(k, pred=lambda v: bool(v), msg=None):
    v=data.get(k,'')
    if not pred(v): errors.append(msg or f'{k} задан некорректно')
need('ENVIRONMENT', lambda v:v=='production','ENVIRONMENT должен быть production')
need('PUBLIC_URL', lambda v:v.startswith('https://'),'PUBLIC_URL должен использовать HTTPS')
need('JWT_SECRET', lambda v:len(v)>=48,'JWT_SECRET должен быть случайной строкой минимум 48 символов')
need('POSTGRES_PASSWORD', lambda v:len(v)>=20,'POSTGRES_PASSWORD слишком короткий')
need('REDIS_PASSWORD', lambda v:len(v)>=20,'REDIS_PASSWORD слишком короткий')
need('COOKIE_SECURE', lambda v:v.lower()=='true','COOKIE_SECURE=true обязателен')
need('SEED_STARTER_CORPUS', lambda v:v.lower()=='false','SEED_STARTER_CORPUS=false обязателен для production')
need('ENABLE_DOCS', lambda v:v.lower()=='false','ENABLE_DOCS=false обязателен для публичного production')
need('ANTIVIRUS_REQUIRED', lambda v:v.lower()=='true','ANTIVIRUS_REQUIRED=true обязателен для публичной загрузки файлов')
for k in ['COMPANY_NAME','COMPANY_INN','COMPANY_OGRN','LEGAL_ADDRESS','SUPPORT_EMAIL','DOMAIN']:
    need(k)
if data.get('COMMERCIAL_MODE','true').lower()=='true':
    need('BILLING_PROVIDER', lambda v:v=='yookassa','Для коммерческого режима настройте BILLING_PROVIDER=yookassa')
if data.get('LLM_PROVIDER')=='openai_compatible': need('LLM_API_KEY')
if data.get('EMBEDDING_PROVIDER')=='openai_compatible':
    if not (data.get('EMBEDDING_API_KEY') or data.get('LLM_API_KEY')): errors.append('Для embeddings нужен EMBEDDING_API_KEY или LLM_API_KEY')
if errors:
    print('❌ Production preflight:')
    for e in errors: print('  -',e)
    sys.exit(1)
print('✅ Переменные production прошли preflight')
PY

if ! command -v docker >/dev/null 2>&1 || ! docker info >/dev/null 2>&1; then
  echo "❌ Docker недоступен"
  exit 1
fi

docker compose --env-file "$ENV_FILE" -f docker-compose.production.yml config >/dev/null
echo "✅ docker-compose.production.yml валиден"
echo "✅ Preflight завершен. Это техническая проверка; правовой корпус и юридические документы всё равно должны быть утверждены перед продажей."
