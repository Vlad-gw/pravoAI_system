#!/bin/bash
set -e
cd "$(dirname "$0")"
docker compose --profile docker-ai down --remove-orphans || true
echo "ПравоAI остановлен. Нативный Ollama (если используется) не останавливается, чтобы не мешать другим приложениям."
